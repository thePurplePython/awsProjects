// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process autoclave device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr, lit, when, translate}

/*
spark-submit \
--class "autoclavesIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/transform-autoclave-devices-dataset_2.11-1.0.jar" \
256 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet/" \
"AC1,AC2,AC3,AC_4,AC5" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac1-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac2-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac3-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac4-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac5-data-items.txt" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac2-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac3-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac4-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac5-silver.parquet" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac2-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac3-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac4-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac5-silver.csv" \
8 \
50
*/

object autoclavesIiotApp {
        
        def main(args: Array[String]) {
            
            val partitions = args(0).toInt
            val inputPath = args(1)
            val device = args(2).split(",")
            val headerPaths = args(3).split(",")
            val stagePaths = args(4).split(",")
            val parquetPaths = args(5).split(",")
            val csvPaths = args(6).split(",")
            val parquetRepartition = args(7).toInt
            val csvRepartition = args(8).toInt
        
        /*
        val partitions = 256
        val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
        val device = "AC1"
        val headerPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac1-data-items.txt"
        val stagePaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv"
        val parquetPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet"
        val csvPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac1-silver.csv"
        val parquetRepartition = 8
        val csvRepartition = 50
        */

            println("ac1 started")
            shuffles(partitions)
            val ac1ParquetDf = parquetTransform(inputPath, device(0))
            val ac1UnionDf = unionTransform(ac1ParquetDf)
            val ac1Bv = broadcastTransform(headerPaths(0))
            val ac1PivotsDf = pivotTransform(ac1UnionDf, ac1Bv)
            csvStage(ac1PivotsDf, stagePaths(0))
            val ac1SchemaDf = inferSchema(stagePaths(0))
            val ac1TypedDf = typedSchema(ac1SchemaDf, stagePaths(0))
            parquetWrite(ac1TypedDf, parquetRepartition, parquetPaths(0))
            csvWrite(ac1TypedDf, csvRepartition, csvPaths(0))
            bvDestroy(ac1Bv)
            println("ac1 completed")
            println("ac2 started")
            shuffles(partitions)
            val ac2ParquetDf = parquetTransform(inputPath, device(1))
            val ac2UnionDf = unionTransform(ac2ParquetDf)
            val ac2Bv = broadcastTransform(headerPaths(1))
            val ac2PivotsDf = pivotTransform(ac2UnionDf, ac2Bv)
            csvStage(ac2PivotsDf, stagePaths(1))
            val ac2SchemaDf = inferSchema(stagePaths(1))
            val ac2TypedDf = typedSchema(ac2SchemaDf, stagePaths(1))
            parquetWrite(ac2TypedDf, parquetRepartition, parquetPaths(1))
            csvWrite(ac2TypedDf, csvRepartition, csvPaths(1))
            bvDestroy(ac2Bv)
            println("ac2 completed")
            println("ac3 started")
            shuffles(partitions)
            val ac3ParquetDf = parquetTransform(inputPath, device(2))
            val ac3UnionDf = unionTransform(ac3ParquetDf)
            val ac3Bv = broadcastTransform(headerPaths(2))
            val ac3PivotsDf = pivotTransform(ac3UnionDf, ac3Bv)
            csvStage(ac3PivotsDf, stagePaths(2))
            val ac3SchemaDf = inferSchema(stagePaths(2))
            val ac3CastDf = (ac3SchemaDf
            .withColumn("ac3_event_rawtranscurrdaub", col("ac3_event_rawtranscurrdaub").cast("double"))
            .withColumn("ac3_event_rawtranscurr", col("ac3_event_rawtranscurr").cast("double")))
            val ac3TypedDf = typedSchema(ac3CastDf, stagePaths(2))
            parquetWrite(ac3TypedDf, parquetRepartition, parquetPaths(2))
            csvWrite(ac3TypedDf, csvRepartition, csvPaths(2))
            bvDestroy(ac3Bv)
            println("ac3 completed")
            println("ac4 started")
            shuffles(partitions)
            val ac4ParquetDf = parquetTransform(inputPath, device(3))
            val ac4UnionDf = unionTransform(ac4ParquetDf)
            val ac4Bv = broadcastTransform(headerPaths(3))
            val ac4PivotsDf = pivotTransform(ac4UnionDf, ac4Bv)
            csvStage(ac4PivotsDf, stagePaths(3))
            val ac4SchemaDf = inferSchema(stagePaths(3))
            val ac4TypedDf = typedSchema(ac4SchemaDf, stagePaths(3))
            parquetWrite(ac4TypedDf, parquetRepartition, parquetPaths(3))
            csvWrite(ac4TypedDf, csvRepartition, csvPaths(3))
            bvDestroy(ac4Bv)
            println("ac4 completed")
            println("ac5 started")
            shuffles(partitions)
            val ac5ParquetDf = parquetTransform(inputPath, device(4))
            val ac5UnionDf = unionTransform(ac5ParquetDf)
            val ac5Bv = broadcastTransform(headerPaths(4))
            val ac5PivotsDf = pivotTransform(ac5UnionDf, ac5Bv)
            csvStage(ac5PivotsDf, stagePaths(4))
            val ac5SchemaDf = inferSchema(stagePaths(4))
            val ac5TypedDf = typedSchema(ac5SchemaDf, stagePaths(4))
            parquetWrite(ac5TypedDf, parquetRepartition, parquetPaths(4))
            csvWrite(ac5TypedDf, csvRepartition, csvPaths(4))
            bvDestroy(ac5Bv)
            println("ac5 completed")
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("pivot-autoclaves-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // shuffles
        def shuffles(partitions: Int): Unit = {
          return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

        // read parquet table and filter dataset for specific device
        def parquetTransform(inputPath: String, device: String): DataFrame = {
          val parquetDf = spark
          .read
          .parquet(inputPath)
          .select(date_format(col("timestamp"), "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
          .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
          .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
          .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
          .filter((col("deviceName") === device))
          return parquetDf
        }

        // union values (event, sample, condition) to collect data-item tags
        def unionTransform(df: DataFrame): DataFrame = {
          val conditionDf = df
          .withColumnRenamed("valueCondition", "value")
          .filter("category = 'CONDITION'")
          .drop("valueSample", "valueEvent")
          val eventDf = df
          .withColumnRenamed("valueEvent", "value")
          .filter("category = 'EVENT'")
          .drop("valueSample", "valueCondition")
          val sampleDf = df
          .withColumnRenamed("valueSample", "value")
          .filter("category = 'SAMPLE'")
          .drop("valueEvent", "valueCondition")
          val unionDf = conditionDf
          .union(eventDf)
          .union(sampleDf)
          return unionDf
        }

        // read txt file with distinct data-items and convert to list for broadcast variable
        def broadcastTransform(headerPaths: String): Broadcast[Array[Any]] = {
          val df = spark
          .read
          .format("csv")
          .option("header", "true")
          .load(headerPaths)
          val items = df.rdd.map(x => x(0)).collect()
          val bv = spark.sparkContext.broadcast(items)
          return bv
        }

        // pivot unique data--item rows to columns
        def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
          val pivotDf = df
          .groupBy("timestamp")
          .pivot("dataItemId", bv.value)
          .agg(expr("first(value)"))
          return pivotDf
        }

        // write to csv for schema inference
        def csvStage(df: DataFrame, stagePaths: String) {
          return df
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "true")
          .mode("overwrite")
          .save(stagePaths)
        }

        // map schema to df
        def inferSchema(stagePaths: String): DataFrame = {
          val schemaDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(stagePaths)
          return schemaDf
        }

        // map types to df
        def typedSchema(df: DataFrame, stagePaths: String): DataFrame = {
          val schema = df.schema
          val typedDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .schema(schema)
          .load(stagePaths)
          return typedDf
        }

        // write to parquet
        def parquetWrite(df: DataFrame, parquetRepartition: Int, parquetPaths: String) {
          return df
          .repartition(parquetRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("parquet")
          .mode("overwrite")
          .save(parquetPaths)
        }

        // write to csv
        def csvWrite(df: DataFrame, csvRepartition: Int, csvPaths: String) {
          return df
          .repartition(csvRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "false")
          .mode("overwrite")
          .save(csvPaths)
        }

        // kill broadcast variable
        def bvDestroy(bv: Broadcast[Array[Any]]): Unit = {
          return bv.destroy()
        }

        // end sess
        def kill(): Unit = {
          return spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics