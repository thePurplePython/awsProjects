// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process drill device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr, lit, when, translate}

/*
spark-submit \
--class "drillsIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/transform-drill-devices-dataset_2.11-1.0.jar" \
256 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet/" \
"FAD_1,FAD_2" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad2-data-items.txt" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad2-silver.csv" \
8 \
50
*/

object drillsIiotApp {
        
        def main(args: Array[String]) {
            
            val partitions = args(0).toInt
            val inputPath = args(1)
            val device = args(2).split(",")
            val headerPaths = args(3).split(",")
            val stagePaths = args(4).split(",")
            val parquetPaths = args(5).split(",")
            val csvPaths = args(6).split(",")
            val parquetRepartition = args(7).toInt
            val csvRepartition = args(8).toInt
        
        /*
        val partitions = 256
        val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
        val device = "FAD_1"
        val headerPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt"
        val stagePaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv"
        val parquetPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet"
        val csvPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad1-silver.csv"
        val parquetRepartition = 8
        val csvRepartition = 50
        */

            println("fad1 started")
            shuffles(partitions)
            val fad1ParquetDf = parquetTransform(inputPath, device(0))
            val fad1UnionDf = unionTransform(fad1ParquetDf)
            val fad1Bv = broadcastTransform(headerPaths(0))
            val fad1PivotsDf = pivotTransform(fad1UnionDf, fad1Bv)
            csvStage(fad1PivotsDf, stagePaths(0))
            val fad1SchemaDf = inferSchema(stagePaths(0))
            val fad1TypedDf = typedSchema(fad1SchemaDf, stagePaths(0))
            parquetWrite(fad1TypedDf, parquetRepartition, parquetPaths(0))
            csvWrite(fad1TypedDf, csvRepartition, csvPaths(0))
            bvDestroy(fad1Bv)
            println("fad1 completed")
            println("fad2 started")
            shuffles(partitions)
            val fad2ParquetDf = parquetTransform(inputPath, device(1))
            val fad2UnionDf = unionTransform(fad2ParquetDf)
            val fad2Bv = broadcastTransform(headerPaths(1))
            val fad2PivotsDf = pivotTransform(fad2UnionDf, fad2Bv)
            csvStage(fad2PivotsDf, stagePaths(1))
            val fad2SchemaDf = inferSchema(stagePaths(1))
            val fad2CastDf = (fad2SchemaDf
            .withColumn("fad_2_sample_bd_energy", col("fad_2_sample_bd_energy").cast("double"))
            .withColumn("fad_2_sample_zd_energy", col("fad_2_sample_zd_energy").cast("double"))
            .withColumn("fad_2_sample_wd_energy", col("fad_2_sample_wd_energy").cast("double"))
            .withColumn("fad_2_sample_ysd_energy", col("fad_2_sample_ysd_energy").cast("double"))
            .withColumn("fad_2_sample_t_wd_energy", col("fad_2_sample_t_wd_energy").cast("double"))
            .withColumn("fad_2_sample_x2d_energy", col("fad_2_sample_x2d_energy").cast("double"))
            .withColumn("fad_2_sample_cd_energy", col("fad_2_sample_cd_energy").cast("double")))
            val fad2TypedDf = typedSchema(fad2CastDf, stagePaths(1))
            parquetWrite(fad2TypedDf, parquetRepartition, parquetPaths(1))
            csvWrite(fad2TypedDf, csvRepartition, csvPaths(1))
            bvDestroy(fad2Bv)
            println("fad2 completed")
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("pivot-drills-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // shuffles
        def shuffles(partitions: Int): Unit = {
          return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

        // read parquet table and filter dataset for specific device
        def parquetTransform(inputPath: String, device: String): DataFrame = {
          val parquetDf = spark
          .read
          .parquet(inputPath)
          .select(date_format(col("timestamp"), "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
          .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
          .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
          .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
          .filter((col("deviceName") === device))
          return parquetDf
        }

        // union values (event, sample, condition) to collect data-item tags
        def unionTransform(df: DataFrame): DataFrame = {
          val conditionDf = df
          .withColumnRenamed("valueCondition", "value")
          .filter("category = 'CONDITION'")
          .drop("valueSample", "valueEvent")
          val eventDf = df
          .withColumnRenamed("valueEvent", "value")
          .filter("category = 'EVENT'")
          .drop("valueSample", "valueCondition")
          val sampleDf = df
          .withColumnRenamed("valueSample", "value")
          .filter("category = 'SAMPLE'")
          .drop("valueEvent", "valueCondition")
          val unionDf = conditionDf
          .union(eventDf)
          .union(sampleDf)
          return unionDf
        }

        // read txt file with distinct data-items and convert to list for broadcast variable
        def broadcastTransform(headerPaths: String): Broadcast[Array[Any]] = {
          val df = spark
          .read
          .format("csv")
          .option("header", "true")
          .load(headerPaths)
          val items = df.rdd.map(x => x(0)).collect()
          val bv = spark.sparkContext.broadcast(items)
          return bv
        }

        // pivot unique data--item rows to columns
        def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
          val pivotDf = df
          .groupBy("timestamp")
          .pivot("dataItemId", bv.value)
          .agg(expr("first(value)"))
          return pivotDf
        }

        // write to csv for schema inference
        def csvStage(df: DataFrame, stagePaths: String) {
          return df
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "true")
          .mode("overwrite")
          .save(stagePaths)
        }

        // map schema to df
        def inferSchema(stagePaths: String): DataFrame = {
          val schemaDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(stagePaths)
          return schemaDf
        }

        // map types to df
        def typedSchema(df: DataFrame, stagePaths: String): DataFrame = {
          val schema = df.schema
          val typedDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .schema(schema)
          .load(stagePaths)
          return typedDf
        }

        // write to parquet
        def parquetWrite(df: DataFrame, parquetRepartition: Int, parquetPaths: String) {
          return df
          .repartition(parquetRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("parquet")
          .mode("overwrite")
          .save(parquetPaths)
        }

        // write to csv
        def csvWrite(df: DataFrame, csvRepartition: Int, csvPaths: String) {
          return df
          .repartition(csvRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "false")
          .mode("overwrite")
          .save(csvPaths)
        }

        // kill broadcast variable
        def bvDestroy(bv: Broadcast[Array[Any]]): Unit = {
          return bv.destroy()
        }

        // end sess
        def kill(): Unit = {
          return spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics