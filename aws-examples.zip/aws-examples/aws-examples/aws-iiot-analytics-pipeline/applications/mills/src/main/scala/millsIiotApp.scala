!// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process mill device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr, lit, when, translate}

/*
spark-submit \
--class "millsIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/transform-mill-devices-dataset_2.11-1.0.jar" \
256 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet/" \
"FOG_1,FOG_2,DIAMOND_NORTH,DIAMOND_SOUTH" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog1-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog2-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-north-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-south-data-items.txt" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog1-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog2-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-north-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-south-silver.parquet" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog1-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog2-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-north-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-south-silver.csv" \
8 \
50
*/

object millsIiotApp {
        
        def main(args: Array[String]) {
            
            val partitions = args(0).toInt
            val inputPath = args(1)
            val device = args(2).split(",")
            val headerPaths = args(3).split(",")
            val stagePaths = args(4).split(",")
            val parquetPaths = args(5).split(",")
            val csvPaths = args(6).split(",")
            val parquetRepartition = args(7).toInt
            val csvRepartition = args(8).toInt
        
        /*
        val partitions = 256
        val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
        val device = "FOG_1"
        val headerPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog1-data-items.txt"
        val stagePaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv"
        val parquetPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog1-silver.parquet"
        val csvPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog1-silver.csv"
        val parquetRepartition = 8
        val csvRepartition = 50
        */

            println("fog1 started")
            shuffles(partitions)
            val fog1ParquetDf = parquetTransform(inputPath, device(0))
            val fog1UnionDf = unionTransform(fog1ParquetDf)
            val fog1Bv = broadcastTransform(headerPaths(0))
            val fog1PivotsDf = pivotTransform(fog1UnionDf, fog1Bv)
            csvStage(fog1PivotsDf, stagePaths(0))
            val fog1SchemaDf = inferSchema(stagePaths(0))
            val fog1TypedDf = typedSchema(fog1SchemaDf, stagePaths(0))
            parquetWrite(fog1TypedDf, parquetRepartition, parquetPaths(0))
            csvWrite(fog1TypedDf, csvRepartition, csvPaths(0))
            bvDestroy(fog1Bv)
            println("fog1 completed")
            println("fog2 started")
            shuffles(partitions)
            val fog2ParquetDf = parquetTransform(inputPath, device(1))
            val fog2UnionDf = unionTransform(fog2ParquetDf)
            val fog2Bv = broadcastTransform(headerPaths(1))
            val fog2PivotsDf = pivotTransform(fog2UnionDf, fog2Bv)
            csvStage(fog2PivotsDf, stagePaths(1))
            val fog2SchemaDf = inferSchema(stagePaths(1))
            val fog2TypedDf = typedSchema(fog2SchemaDf, stagePaths(1))
            parquetWrite(fog2TypedDf, parquetRepartition, parquetPaths(1))
            csvWrite(fog2TypedDf, csvRepartition, csvPaths(1))
            bvDestroy(fog2Bv)
            println("fog2 completed")
            println("dnorth started")
            shuffles(partitions)
            val dnorthParquetDf = parquetTransform(inputPath, device(2))
            val dnorthUnionDf = unionTransform(dnorthParquetDf)
            val dnorthBv = broadcastTransform(headerPaths(2))
            val dnorthPivotsDf = pivotTransform(dnorthUnionDf, dnorthBv)
            csvStage(dnorthPivotsDf, stagePaths(2))
            val dnorthSchemaDf = inferSchema(stagePaths(2))
            val dnorthCastDf = (dnorthSchemaDf
            .withColumn("diamond_north_sample_y_m_motor_energy", col("diamond_north_sample_y_m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_sp_m_motor_energy", col("diamond_north_sample_sp_m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_z_m_motor_energy", col("diamond_north_sample_z_m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_x_m_motor_energy", col("diamond_north_sample_x_m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_tc_1m_motor_energy", col("diamond_north_sample_tc_1m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_a_m_motor_energy", col("diamond_north_sample_a_m_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_x_sm_motor_energy", col("diamond_north_sample_x_sm_motor_energy").cast("double"))
            .withColumn("diamond_north_sample_c_m_motor_energy", col("diamond_north_sample_c_m_motor_energy").cast("double")))
            val dnorthTypedDf = typedSchema(dnorthCastDf, stagePaths(2))
            parquetWrite(dnorthTypedDf, parquetRepartition, parquetPaths(2))
            csvWrite(dnorthTypedDf, csvRepartition, csvPaths(2))
            bvDestroy(dnorthBv)
            println("dnorth completed")
            println("dsouth started")
            shuffles(partitions)
            val dsouthParquetDf = parquetTransform(inputPath, device(3))
            val dsouthUnionDf = unionTransform(dsouthParquetDf)
            val dsouthBv = broadcastTransform(headerPaths(3))
            val dsouthPivotsDf = pivotTransform(dsouthUnionDf, dsouthBv)
            csvStage(dsouthPivotsDf, stagePaths(3))
            val dsouthSchemaDf = inferSchema(stagePaths(3))
            val dsouthCastDf = (dsouthSchemaDf
            .withColumn("diamond_south_sample_x_sm_motor_energy", col("diamond_south_sample_x_sm_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_c_m_motor_energy", col("diamond_south_sample_c_m_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_z_m_motor_energy", col("diamond_south_sample_z_m_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_sp_m_motor_energy", col("diamond_south_sample_sp_m_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_x_m_motor_energy", col("diamond_south_sample_x_m_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_a_m_motor_energy", col("diamond_south_sample_a_m_motor_energy").cast("double"))
            .withColumn("diamond_south_sample_y_m_motor_energy", col("diamond_south_sample_y_m_motor_energy").cast("double")))
            val dsouthTypedDf = typedSchema(dsouthCastDf, stagePaths(3))
            parquetWrite(dsouthTypedDf, parquetRepartition, parquetPaths(3))
            csvWrite(dsouthTypedDf, csvRepartition, csvPaths(3))
            bvDestroy(dsouthBv)
            println("dsouth completed")
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("pivot-mills-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // shuffles
        def shuffles(partitions: Int): Unit = {
          return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

        // read parquet table and filter dataset for specific device
        def parquetTransform(inputPath: String, device: String): DataFrame = {
          val parquetDf = spark
          .read
          .parquet(inputPath)
          .select(date_format(col("timestamp"), "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
          .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
          .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
          .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
          .filter((col("deviceName") === device))
          return parquetDf
        }

        // union values (event, sample, condition) to collect data-item tags
        def unionTransform(df: DataFrame): DataFrame = {
          val conditionDf = df
          .withColumnRenamed("valueCondition", "value")
          .filter("category = 'CONDITION'")
          .drop("valueSample", "valueEvent")
          val eventDf = df
          .withColumnRenamed("valueEvent", "value")
          .filter("category = 'EVENT'")
          .drop("valueSample", "valueCondition")
          val sampleDf = df
          .withColumnRenamed("valueSample", "value")
          .filter("category = 'SAMPLE'")
          .drop("valueEvent", "valueCondition")
          val unionDf = conditionDf
          .union(eventDf)
          .union(sampleDf)
          return unionDf
        }

        // read txt file with distinct data-items and convert to list for broadcast variable
        def broadcastTransform(headerPaths: String): Broadcast[Array[Any]] = {
          val df = spark
          .read
          .format("csv")
          .option("header", "true")
          .load(headerPaths)
          val items = df.rdd.map(x => x(0)).collect()
          val bv = spark.sparkContext.broadcast(items)
          return bv
        }

        // pivot unique data--item rows to columns
        def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
          val pivotDf = df
          .groupBy("timestamp")
          .pivot("dataItemId", bv.value)
          .agg(expr("first(value)"))
          return pivotDf
        }

        // write to csv for schema inference
        def csvStage(df: DataFrame, stagePaths: String) {
          return df
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "true")
          .mode("overwrite")
          .save(stagePaths)
        }

        // map schema to df
        def inferSchema(stagePaths: String): DataFrame = {
          val schemaDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(stagePaths)
          return schemaDf
        }

        // map types to df
        def typedSchema(df: DataFrame, stagePaths: String): DataFrame = {
          val schema = df.schema
          val typedDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .schema(schema)
          .load(stagePaths)
          return typedDf
        }

        // write to parquet
        def parquetWrite(df: DataFrame, parquetRepartition: Int, parquetPaths: String) {
          return df
          .repartition(parquetRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("parquet")
          .mode("overwrite")
          .save(parquetPaths)
        }

        // write to csv
        def csvWrite(df: DataFrame, csvRepartition: Int, csvPaths: String) {
          return df
          .repartition(csvRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "false")
          .mode("overwrite")
          .save(csvPaths)
        }

        // kill broadcast variable
        def bvDestroy(bv: Broadcast[Array[Any]]): Unit = {
          return bv.destroy()
        }

        // end sess
        def kill(): Unit = {
          return spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics