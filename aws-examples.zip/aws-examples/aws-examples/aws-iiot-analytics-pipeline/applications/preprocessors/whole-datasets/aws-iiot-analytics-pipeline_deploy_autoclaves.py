# garrett r peternel | data scientist | lm aeronautics 

import boto3
import pandas as pd
import numpy as np
import pyarrow
import io
import re
from sklearn.preprocessing import MinMaxScaler

def header(bucket, key):
    s3_client = boto3.client('s3')
    file = s3_client.get_object(Bucket=bucket, Key=key)
    body = file['Body']
    return body.read().decode('utf-8').split()

def parser_string(match='', col_list=[]):
    r = re.compile(match)
    cols = list(filter(r.match, col_list))
    return cols

def s3_single_parquet_file(key, bucket, s3_client=None, **kwargs):
    if s3_client is None:
        s3_client = boto3.client('s3')
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    return pd.read_parquet(io.BytesIO(obj['Body'].read()), **kwargs)

def s3_multi_parquet_files(prefix, bucket, s3=None, s3_client=None, **kwargs):
    if not prefix.endswith('/'):
        prefix = prefix + '/'
    if s3_client is None:
        s3_client = boto3.client('s3')
    if s3 is None:
        s3 = boto3.resource('s3')
    s3_keys = [item.key for item in s3.Bucket(bucket).objects.filter(Prefix=prefix) if item.key.endswith('.parquet')]
    data = [s3_single_parquet_file(key, bucket=bucket, s3_client=s3_client, **kwargs) for key in s3_keys]
    return pd.concat(data, ignore_index=True)

def sortby(df, **kwargs):
    df.sort_values(**kwargs, inplace=True)
    df.reset_index(drop=True, inplace=True)
    df.set_index(['timestamp'], inplace=True)
    return df

def imputer(df):
    df.interpolate(method='linear', limit_direction='both', inplace=True)
    return df
	
def scales(df):
    mms = MinMaxScaler()
    df = pd.DataFrame(mms.fit_transform(df.values), columns=df.columns, index=df.index)
    df.reset_index(inplace=True)
    return df

def ts_to_epoch(df):
    df['timestamp'] = df['timestamp'].astype('int')
    return df

def drop(df):
    df = df.drop_duplicates()
    return df

def save_df_train_chunks(pdf, prefix, rows, path):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket('aero-iiot')
    bucket.objects.filter(Prefix=prefix).delete()
    chunks = round(len(pdf) / rows)
    return [df.drop('timestamp', axis=1).to_csv(path + 'part-{i}.csv'.format(i=i), index=False, header=False) for i, df in  enumerate(np.array_split(pdf, chunks))]

def save_df_batch_chunks(pdf, prefix, rows, path):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket('aero-iiot')
    bucket.objects.filter(Prefix=prefix).delete()
    chunks = round(len(pdf) / rows)
    return [df.to_csv(path + 'part-{i}.csv'.format(i=i), index=False, header=False) for i, df in  enumerate(np.array_split(pdf, chunks))]

if __name__ == "__main__":
    
    # ac1
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/ac1-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_parquet_df = s3_multi_parquet_files('datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet/', 'aero-iiot', engine='pyarrow', columns=['timestamp'] + cols)
    multi_parquet_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_parquet_df = sortby(multi_parquet_df, by=['timestamp'])
    imputer_df = imputer(sorted_multi_parquet_df)
    scaler_df = scales(imputer_df)
    epochs_df = ts_to_epoch(scaler_df)
    write_df = drop(epochs_df)
    save_df_train_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac1/train/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac1/train/')
    save_df_batch_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac1/batch/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac1/batch/')
    del lines
    del cols
    del multi_parquet_df
    del sorted_multi_parquet_df
    del imputer_df
    del scaler_df
    del epochs_df
    del write_df
    
    # ac2
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/ac2-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_parquet_df = s3_multi_parquet_files('datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac2-silver.parquet/', 'aero-iiot', engine='pyarrow', columns=['timestamp'] + cols)
    multi_parquet_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_parquet_df = sortby(multi_parquet_df, by=['timestamp'])
    imputer_df = imputer(sorted_multi_parquet_df)
    scaler_df = scales(imputer_df)
    epochs_df = ts_to_epoch(scaler_df)
    write_df = drop(epochs_df)
    save_df_train_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac2/train/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac2/train/')
    save_df_batch_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac2/batch/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac2/batch/')
    del lines
    del cols
    del multi_parquet_df
    del sorted_multi_parquet_df
    del imputer_df
    del scaler_df
    del epochs_df
    del write_df

    # ac3
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/ac3-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_parquet_df = s3_multi_parquet_files('datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac3-silver.parquet/', 'aero-iiot', engine='pyarrow', columns=['timestamp'] + cols)
    multi_parquet_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_parquet_df = sortby(multi_parquet_df, by=['timestamp'])
    imputer_df = imputer(sorted_multi_parquet_df)
    scaler_df = scales(imputer_df)
    epochs_df = ts_to_epoch(scaler_df)
    write_df = drop(epochs_df)
    save_df_train_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac3/train/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac3/train/')
    save_df_batch_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac3/batch/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac3/batch/')
    del lines
    del cols
    del multi_parquet_df
    del sorted_multi_parquet_df
    del imputer_df
    del scaler_df
    del epochs_df
    del write_df

    # ac4
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/ac4-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_parquet_df = s3_multi_parquet_files('datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac4-silver.parquet/', 'aero-iiot', engine='pyarrow', columns=['timestamp'] + cols)
    multi_parquet_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_parquet_df = sortby(multi_parquet_df, by=['timestamp'])
    imputer_df = imputer(sorted_multi_parquet_df)
    scaler_df = scales(imputer_df)
    epochs_df = ts_to_epoch(scaler_df)
    write_df = drop(epochs_df)
    save_df_train_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac4/train/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac4/train/')
    save_df_batch_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac4/batch/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac4/batch/')
    del lines
    del cols
    del multi_parquet_df
    del sorted_multi_parquet_df
    del imputer_df
    del scaler_df
    del epochs_df
    del write_df

    # ac5
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/ac5-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_parquet_df = s3_multi_parquet_files('datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac5-silver.parquet/', 'aero-iiot', engine='pyarrow', columns=['timestamp'] + cols)
    multi_parquet_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_parquet_df = sortby(multi_parquet_df, by=['timestamp'])
    imputer_df = imputer(sorted_multi_parquet_df)
    scaler_df = scales(imputer_df)
    epochs_df = ts_to_epoch(scaler_df)
    write_df = drop(epochs_df)
    save_df_train_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac5/train/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac5/train/')
    save_df_batch_chunks(write_df, 'datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac5/batch/', 100000, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/datasets/ac5/batch/')
    del lines
    del cols
    del multi_parquet_df
    del sorted_multi_parquet_df
    del imputer_df
    del scaler_df
    del epochs_df
    del write_df