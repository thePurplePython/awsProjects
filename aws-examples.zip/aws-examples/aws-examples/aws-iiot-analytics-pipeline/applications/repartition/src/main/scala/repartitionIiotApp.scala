// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => repartition data to optimize file size
// *** prototype ***

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{add_months, current_date, desc, to_date, col}

/*
spark-submit \
--class "repartitionIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/repartition-iiot-last-n-months-file-size-optimizer_2.11-1.0.jar" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/historical-stream-s3-parquet-sink-iron.parquet/" \
-12 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/stream-s3-parquet-sink-iron.parquet/" \
-12 \
2001 \
300000 \
128 \
3 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
*/

object repartitionIiotApp {
        
        def main(args: Array[String]) {
            
            val baseHistoricPath = args(0)
            val historyMask = args(1).toInt
            val basePath = args(2)
            val mask = args(3).toInt
            val partitions = args(4).toInt
            val size = args(5).toInt
            val file = args(6).toInt
            val multiplier = args(7).toInt
            val targetPath = args(8)
        
        /*
        val baseHistoricPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/historical-stream-s3-parquet-sink-iron.parquet/"
        val historyMask = -12
        val basePath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/stream-s3-parquet-sink-iron.parquet/"
        val mask = -12
        val partitions = 2001
        val size = 200000 // megabytes
        val file = 128
        val multiplier = 2
        val targetPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
        */

            val historyDf = readHistoricParquet(baseHistoricPath, historyMask)
            val filterDf = readParquet(basePath, mask)
            val unionDf = union(historyDf, filterDf)
            shuffles(partitions)
            val numPartitions = num(unionDf)
            val sizeDf = megabytes(size)
            val fileDf = files(file)
            val defaultParallelism = dp()
            val maxDf = max(defaultParallelism, multiplier, sizeDf, fileDf)
            val repartitionDf = split(unionDf, maxDf)
            writeParquet(repartitionDf, targetPath)
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("repartition-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // read
        def readHistoricParquet(baseHistoricPath: String, historyMask: Int): DataFrame = {
          val filterDf = spark
          .read
          .parquet(baseHistoricPath)
          .filter(col("timestamp") >= add_months(current_date(), historyMask))
          return filterDf
        }

        // read
        def readParquet(basePath: String, mask: Int): DataFrame = {
          val filterDf = spark
          .read
          .parquet(basePath)
          .filter(col("timestamp") >= add_months(current_date(), mask))
          return filterDf
        }

        // union dataframes
        def union(df1: DataFrame, df2: DataFrame): DataFrame = {
          val unionDf = df1.union(df2).dropDuplicates()
          return unionDf
        }

        // shuffles
        def shuffles(partitions: Int): Unit = {
          return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

        // number of partitions in filtered dataframe
        def num(df: DataFrame): Int = {
          val numPartitions = df.rdd.getNumPartitions
          return numPartitions
        }

        // estimate size (megabytes) of dataframe persisted in ram
        def megabytes(size: Int): Int = {
          val sizeDf = size
          return sizeDf
        }
        
        // desired file size output per partition
        def files(file: Int): Int = {
          val fileDf = file
          return fileDf
        }

        // default parallelism
        def dp(): Int = {
          val defaultParallelism  = spark.sparkContext.defaultParallelism
          return defaultParallelism
        }

        // max partition size
        def max(dp: Int, multiplier: Int, size: Int, file: Int): Int = {
          val maxDf = Math.max(dp * multiplier, Math.ceil(size / file).toInt)
          return maxDf
        }

        // repartition dataframe
        def split(df: DataFrame, max: Int): DataFrame = {
          val repartitionDf = df.repartition(max)
          return repartitionDf
        }

        // write to parquet
        def writeParquet(df: DataFrame, targetPath: String) {
          return df.write.format("parquet").mode("overwrite").save(targetPath)
        }

        // end sess
        def kill(): Unit = {
          return spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics