// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => take streaming data from source and feed into mini-batch continuous application
//            to reduce down small files and batch up data into larger files for better performance
//            storage cost ... also flatten out multi-nested json schema for normalized structure
// *** prototype ***

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.functions.{explode}
import org.apache.spark.sql.types.{StructType, StringType, ArrayType, LongType, TimestampType, BooleanType, DoubleType, DateType}

/*
spark-submit \
--class "sssIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/sss-iiot-json-parser-parquet-conversion_2.11-1.0.jar" \
1000 \
"s3://aero-iiot/datasets/greengrass/raw/" \
8 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/logs/stream-s3-parquet-sink-iron-cp" \
"180 seconds" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/stream-s3-parquet-sink-iron.parquet" \
1200000
*/

object sssIiotApp {
        
        def main(args: Array[String]) {
            
            val maxFilesPerTrigger = args(0).toInt
            val basePath = args(1)
            val repartition = args(2).toInt
            val checkpointPath = args(3)
            val trigger = args(4)
            val targetPath = args(5)
            val n = args(6).toInt
        
        /*
        val maxFilesPerTrigger = 1000
        val basePath = "s3://aero-iiot/datasets/greengrass/raw/"
        val repartition = 8
        val checkpointPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/logs/stream-s3-parquet-sink-iron-cp"
        val trigger = "180 seconds"
        val targetPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/stream-s3-parquet-sink-iron.parquet"
        val n = 900000 // 15 min
        */

            val obsDf = readRawJsonStream(maxFilesPerTrigger, basePath)
            val flattenDf = readRawJsonStreamFlatten(obsDf)
            val flattenStructsDf = readRawJsonStreamFlattenStruct(flattenDf)
            spark.conf.set("spark.sql.shuffle.partitions", 2001)
            val normalizeDf = readRawJsonStreamNormalize(flattenStructsDf)
            val triggerDf = readRawJsonStreamTrigger(normalizeDf, repartition, checkpointPath, trigger, targetPath)
            stop(n)
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("sss-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // schema json mapping
        val schema = (new StructType()
          .add("entity", new StructType()
            .add("header", new StructType()
              .add("agentBufferSize", StringType, true)
              .add("agentVersion", StringType, true)
              .add("collectorVersion", StringType, true)
              .add("creationTime", StringType, true)
              .add("deviceName", StringType, true)
              .add("deviceUuid", StringType, true)
              .add("instanceId", StringType, true)
              .add("schemaVersion", StringType, true)
              .add("sender", StringType, true)))
          .add("observations", ArrayType(new StructType()
            .add("entity", new StructType()
              .add("observation", new StructType()
                .add("category", StringType, true)
                .add("dataItemId", StringType, true)
                .add("dataItemName", StringType, true)
                .add("dataItemPath", ArrayType(new StructType()
                  .add("Actuator", StringType, true)
                  .add("Axes", StringType, true)
                  .add("Controller", StringType, true)
                  .add("Coolant", StringType, true)
                  .add("Device", StringType, true)
                  .add("Linear", StringType, true)
                  .add("Path", StringType, true)
                  .add("Rotary", StringType, true)))
                .add("dataItemType", StringType, true)
                .add("dimensions", new StructType()
                  .add("receivedAt", StringType, true)
                  .add("sequence", LongType, true)
                  .add("timestamp", TimestampType, true)
                  .add("unavailable", BooleanType, true))
                .add("measurements", new StructType()
                  .add("valueCondition", StringType, true)
                  .add("valueEvent", StringType, true)
                  .add("valueSample", DoubleType, true))
                .add("nativeUnits", StringType, true)
                .add("subType", StringType, true)
                .add("units", StringType, true)))))
          .add("type", StringType, true)
          .add("date", DateType, true))

        // 1st flattening layer
        def readRawJsonStream(maxFilesPerTrigger: Int, basePath: String): DataFrame = {
            val obsDf = spark
            .readStream
            .option("maxFilesPerTrigger", maxFilesPerTrigger)
            .option("latestFirst", true)
            .schema(schema)
            .json(basePath)
            .select($"entity.header.*", explode($"observations.entity.observation").as("obs"))
            return obsDf
        }

        // 2nd flattening layer
        def readRawJsonStreamFlatten(df: DataFrame): DataFrame = {
            val flattenDf = df
            .select($"*", $"obs.*").drop("obs")
            return flattenDf
        }

        // 3rd flattening layer
        def readRawJsonStreamFlattenStruct(df: DataFrame): DataFrame = {
            val flattenStructsDf = df
            .select($"*", $"dimensions.*", $"measurements.*", explode($"dataItemPath").as("path"))
            .drop("dimensions", "measurements", "dataItemPath")
            return flattenStructsDf
        }

        // 4th flattening layer
        def readRawJsonStreamNormalize(df: DataFrame): DataFrame = {
            val normalizeDf = df
            .select($"*", $"path.*").drop("path")
            return normalizeDf
        }

        // file sink trigger
        def readRawJsonStreamTrigger(df: DataFrame, repartition: Int, checkpointPath: String, trigger: String, targetPath: String): StreamingQuery = {
            val triggerDf = df
            .repartition(repartition)
            .writeStream
            .option("checkpointLocation", checkpointPath)
            .trigger(Trigger.ProcessingTime(trigger))
            .option("path", targetPath)
            .format("parquet")
            .outputMode("append")
            .start()
            //trigger_df.awaitTermination()
            return triggerDf
        }
        
        // sleep
        def stop(n: Int): Unit = {
        	return Thread.sleep(n)
        }

        // end session
        def kill(): Unit = {
          return spark.streams.active.foreach(_.stop()); spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics