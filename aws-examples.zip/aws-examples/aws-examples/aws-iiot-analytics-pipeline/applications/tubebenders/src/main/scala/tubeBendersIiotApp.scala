// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process tube bender device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr, lit, when, translate}

/*
spark-submit \
--class "tubeBendersIiotApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/jars/transform-tube-bender-devices-dataset_2.11-1.0.jar" \
256 \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet/" \
"CRIPPA_NE,CRIPPA_NW,CRIPPA_SE,CRIPPA_SW" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/crippa-ne-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/crippa-nw-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/crippa-se-data-items.txt,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/crippa-sw-data-items.txt" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-crippa-ne-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-crippa-nw-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-crippa-se-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-crippa-sw-silver.csv" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-crippa-ne-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-crippa-nw-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-crippa-se-silver.parquet,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-crippa-sw-silver.parquet" \
"s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-crippa-ne-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-crippa-nw-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-crippa-se-silver.csv,s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-crippa-sw-silver.csv" \
8 \
50
*/

object tubeBendersIiotApp {
        
        def main(args: Array[String]) {
            
            val partitions = args(0).toInt
            val inputPath = args(1)
            val device = args(2).split(",")
            val headerPaths = args(3).split(",")
            val stagePaths = args(4).split(",")
            val parquetPaths = args(5).split(",")
            val csvPaths = args(6).split(",")
            val parquetRepartition = args(7).toInt
            val csvRepartition = args(8).toInt
        
        /*
        val partitions = 256
        val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"
        val device = "CRIPPA_NE"
        val headerPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/crippa-ne-data-items.txt"
        val stagePaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-crippa-ne-silver.csv"
        val parquetPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-crippa-ne-silver.parquet"
        val csvPaths = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-crippa-ne-silver.csv"
        val parquetRepartition = 8
        val csvRepartition = 50
        */

            println("crippane started")
            shuffles(partitions)
            val crippaneParquetDf = parquetTransform(inputPath, device(0))
            val crippaneUnionDf = unionTransform(crippaneParquetDf)
            val crippaneBv = broadcastTransform(headerPaths(0))
            val crippanePivotsDf = pivotTransform(crippaneUnionDf, crippaneBv)
            csvStage(crippanePivotsDf, stagePaths(0))
            val crippaneSchemaDf = inferSchema(stagePaths(0))
            val crippaneTypedDf = typedSchema(crippaneSchemaDf, stagePaths(0))
            parquetWrite(crippaneTypedDf, parquetRepartition, parquetPaths(0))
            csvWrite(crippaneTypedDf, csvRepartition, csvPaths(0))
            bvDestroy(crippaneBv)
            println("crippane completed")
            println("crippanw started")
            shuffles(partitions)
            val crippanwParquetDf = parquetTransform(inputPath, device(1))
            val crippanwUnionDf = unionTransform(crippanwParquetDf)
            val crippanwBv = broadcastTransform(headerPaths(1))
            val crippanwPivotsDf = pivotTransform(crippanwUnionDf, crippanwBv)
            csvStage(crippanwPivotsDf, stagePaths(1))
            val crippanwSchemaDf = inferSchema(stagePaths(1))
            val crippanwTypedDf = typedSchema(crippanwSchemaDf, stagePaths(1))
            parquetWrite(crippanwTypedDf, parquetRepartition, parquetPaths(1))
            csvWrite(crippanwTypedDf, csvRepartition, csvPaths(1))
            bvDestroy(crippanwBv)
            println("crippanw completed")
            println("crippase started")
            shuffles(partitions)
            val crippaseParquetDf = parquetTransform(inputPath, device(2))
            val crippaseUnionDf = unionTransform(crippaseParquetDf)
            val crippaseBv = broadcastTransform(headerPaths(2))
            val crippasePivotsDf = pivotTransform(crippaseUnionDf, crippaseBv)
            csvStage(crippasePivotsDf, stagePaths(2))
            val crippaseSchemaDf = inferSchema(stagePaths(2))
            val crippaseTypedDf = typedSchema(crippaseSchemaDf, stagePaths(2))
            parquetWrite(crippaseTypedDf, parquetRepartition, parquetPaths(2))
            csvWrite(crippaseTypedDf, csvRepartition, csvPaths(2))
            bvDestroy(crippaseBv)
            println("crippase completed")
            println("crippasw started")
            shuffles(partitions)
            val crippaswParquetDf = parquetTransform(inputPath, device(3))
            val crippaswUnionDf = unionTransform(crippaswParquetDf)
            val crippaswBv = broadcastTransform(headerPaths(3))
            val crippaswPivotsDf = pivotTransform(crippaswUnionDf, crippaswBv)
            csvStage(crippaswPivotsDf, stagePaths(3))
            val crippaswSchemaDf = inferSchema(stagePaths(3))
            val crippaswTypedDf = typedSchema(crippaswSchemaDf, stagePaths(3))
            parquetWrite(crippaswTypedDf, parquetRepartition, parquetPaths(3))
            csvWrite(crippaswTypedDf, csvRepartition, csvPaths(3))
            bvDestroy(crippaswBv)
            println("crippasw completed")
            kill()

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("pivot-tube-benders-iiot-app")
          .getOrCreate())

        import spark.implicits._

        // shuffles
        def shuffles(partitions: Int): Unit = {
          return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

        // read parquet table and filter dataset for specific device
        def parquetTransform(inputPath: String, device: String): DataFrame = {
          val parquetDf = spark
          .read
          .parquet(inputPath)
          .select(date_format(col("timestamp"), "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
          .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
          .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
          .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
          .filter((col("deviceName") === device))
          return parquetDf
        }

        // union values (event, sample, condition) to collect data-item tags
        def unionTransform(df: DataFrame): DataFrame = {
          val conditionDf = df
          .withColumnRenamed("valueCondition", "value")
          .filter("category = 'CONDITION'")
          .drop("valueSample", "valueEvent")
          val eventDf = df
          .withColumnRenamed("valueEvent", "value")
          .filter("category = 'EVENT'")
          .drop("valueSample", "valueCondition")
          val sampleDf = df
          .withColumnRenamed("valueSample", "value")
          .filter("category = 'SAMPLE'")
          .drop("valueEvent", "valueCondition")
          val unionDf = conditionDf
          .union(eventDf)
          .union(sampleDf)
          return unionDf
        }

        // read txt file with distinct data-items and convert to list for broadcast variable
        def broadcastTransform(headerPaths: String): Broadcast[Array[Any]] = {
          val df = spark
          .read
          .format("csv")
          .option("header", "true")
          .load(headerPaths)
          val items = df.rdd.map(x => x(0)).collect()
          val bv = spark.sparkContext.broadcast(items)
          return bv
        }

        // pivot unique data-item rows to columns
        def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
          val pivotDf = df
          .groupBy("timestamp")
          .pivot("dataItemId", bv.value)
          .agg(expr("first(value)"))
          return pivotDf
        }

        // write to csv for schema inference
        def csvStage(df: DataFrame, stagePaths: String) {
          return df
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "true")
          .mode("overwrite")
          .save(stagePaths)
        }

        // map schema to df
        def inferSchema(stagePaths: String): DataFrame = {
          val schemaDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(stagePaths)
          return schemaDf
        }

        // map types to df
        def typedSchema(df: DataFrame, stagePaths: String): DataFrame = {
          val schema = df.schema
          val typedDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .schema(schema)
          .load(stagePaths)
          return typedDf
        }

        // write to parquet
        def parquetWrite(df: DataFrame, parquetRepartition: Int, parquetPaths: String) {
          return df
          .repartition(parquetRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("parquet")
          .mode("overwrite")
          .save(parquetPaths)
        }

        // write to csv
        def csvWrite(df: DataFrame, csvRepartition: Int, csvPaths: String) {
          return df
          .repartition(csvRepartition)
          .sortWithinPartitions(col("timestamp"))
          .write
          .format("csv")
          .option("header", "false")
          .mode("overwrite")
          .save(csvPaths)
        }

        // kill broadcast variable
        def bvDestroy(bv: Broadcast[Array[Any]]): Unit = {
          return bv.destroy()
        }

        // end sess
        def kill(): Unit = {
          return spark.stop()
        }

}

// garrett r peternel | spark developer | lm aeronautics