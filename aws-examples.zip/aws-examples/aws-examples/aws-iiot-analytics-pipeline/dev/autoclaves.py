# garrett r peternel | spark developer | lm aeronautics

# *** prototype ***
# summary => transform and pre-process autoclave device data for feature engineering moodeling
# *** prototype ***

# modules
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

# repartitioned data location from spark scala job
PARQUET_SOURCE_PATH = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

# funcs
def string_replacer(x, y):
    """
    summary => replaces string input with string output
    :x => input string value
    :y => output string value
    """
    return F.when(x != y, x).otherwise(F.lit(None))

def parquet_read_df(PATH="", DEVICE=""):
    """
    summary => read parquet table and filter dataset for specific device
    :PATH => input data path
    :DEVICE => device metadata
    """
    parquet_df = spark\
    .read\
    .parquet(PATH)\
    .select(F.date_format(F.col("timestamp"), "yyyy-MM-dd HH:mm:ss").cast("timestamp").alias("timestamp"),\
            "deviceName",\
            "deviceUuid",\
            "category",\
            F.lower(F.translate(F.col("dataItemId"), ". ", "__")).alias("dataItemId"),\
            "valueCondition",\
            "valueEvent",\
            "valueSample")\
    .withColumn("dataItemId", F.concat(F.lower(F.col("deviceName")), F.lit("_"), F.lower(F.col("category")), F.lit("_"), F.col("dataItemId")))\
    .withColumn("valueCondition", string_replacer(F.col("valueCondition"), ""))\
    .withColumn("valueEvent", string_replacer(F.col("valueEvent"), ""))\
    .filter((F.col("deviceName") == DEVICE))
    return parquet_df

def union_transform_df(df):
    """
    summary => union values (event, sample, condition) to collect data-item tags
    :df => input dataframe
    """
    conditions_df = df\
    .withColumnRenamed("valueCondition", "value")\
    .filter("category = 'CONDITION'")\
    .drop("valueSample", "valueEvent")
    events_df = df\
    .withColumnRenamed("valueEvent", "value")\
    .filter("category = 'EVENT'")\
    .drop("valueSample", "valueCondition")
    samples_df = df\
    .withColumnRenamed("valueSample", "value")\
    .filter("category = 'SAMPLE'")\
    .drop("valueEvent", "valueCondition")
    union_df = conditions_df\
    .union(events_df)\
    .union(samples_df)
    return union_df

def df_to_list_to_bv(PATH=""):
    """
    summary => read txt file with distinct data-items and convert to list for broadcast variable
    :PATH => input file path
    """
    df = spark.read.csv(PATH, header=True)
    items = df.rdd.flatMap(lambda x: x).collect()
    bv = spark.sparkContext.broadcast(items)
    return bv

def pivot_transpose_df(df, bv):
    """
    summary => pivot unique data--item rows to columns
    :df => input dataframe
    :bv => broadcast variable
    """
    pivots_df = df\
    .groupBy("timestamp")\
    .pivot('dataItemId', bv.value)\
    .agg(F.expr("first(value)"))
    return pivots_df

def csv_stage_barrier(df, PATH=""):
    """
    summary => write to csv for schema inference
    : df => input dataframe
    : PATH => input file path
    """
    df\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "true")\
    .mode("overwrite")\
    .save(PATH)

def dynamic_infer_schema_types_df(PATH=""):
    """
    summary => infer types
    : PATH => input file path
    """
    schema_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load(PATH)
    return schema_df

def struct_type_schema_df(df, PATH=""):
    """
    summary => map schema to df
    : df => input dataframe
    : PATH => input file path
    """
    schema = df.schema
    typed_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .schema(schema)\
    .load(PATH)
    return typed_df

def write_to_parquet_s3(df, repartition, PATH=""):
    """
    summary => write to parquet
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("parquet")\
    .mode("overwrite")\
    .save(PATH)

def write_to_csv_s3(df, repartition, PATH=""):
    """
    summary => write to csv
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "false")\
    .mode("overwrite")\
    .save(PATH)

def destroy_bv(bv):
    """
    summary => destrory broadcast variable
    : bv => broadcast variable
    """
    return bv.destroy()

def session():
	return spark.stop()

# AC1
print("ac1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
ac1_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "AC1")
ac1_union_df = union_transform_df(ac1_parquet_df)
ac1_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac1-data-items.txt")
ac1_pivots_df = pivot_transpose_df(ac1_union_df, ac1_bv)
csv_stage_barrier(ac1_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
ac1_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
ac1_typed_df = struct_type_schema_df(ac1_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
write_to_parquet_s3(ac1_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet")
write_to_csv_s3(ac1_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac1-silver.csv")
destroy_bv(ac1_bv)
print("ac1 completed")

# AC2
print("ac2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
ac2_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "AC2")
ac2_union_df = union_transform_df(ac2_parquet_df)
ac2_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac2-data-items.txt")
ac2_pivots_df = pivot_transpose_df(ac2_union_df, ac2_bv)
csv_stage_barrier(ac2_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
ac2_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
ac2_typed_df = struct_type_schema_df(ac2_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
write_to_parquet_s3(ac2_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac2-silver.parquet")
write_to_csv_s3(ac2_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac2-silver.csv")
destroy_bv(ac2_bv)
print("ac2 completed")

# AC3
print("ac3 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
ac3_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "AC3")
ac3_union_df = union_transform_df(ac3_parquet_df)
ac3_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac3-data-items.txt")
ac3_pivots_df = pivot_transpose_df(ac3_union_df, ac3_bv)
csv_stage_barrier(ac3_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
ac3_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
ac3_cast_df = ac3_schema_df\
.withColumn("ac3_event_rawtranscurrdaub", F.col("ac3_event_rawtranscurrdaub").cast("double"))\
.withColumn("ac3_event_rawtranscurr", F.col("ac3_event_rawtranscurr").cast("double"))
ac3_typed_df = struct_type_schema_df(ac3_cast_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
write_to_parquet_s3(ac3_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac3-silver.parquet")
write_to_csv_s3(ac3_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac3-silver.csv")
destroy_bv(ac3_bv)
print("ac3 completed")

# AC4
print("ac4 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
ac4_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "AC_4")
ac4_union_df = union_transform_df(ac4_parquet_df)
ac4_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac4-data-items.txt")
ac4_pivots_df = pivot_transpose_df(ac4_union_df, ac4_bv)
csv_stage_barrier(ac4_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
ac4_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
ac4_typed_df = struct_type_schema_df(ac4_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
write_to_parquet_s3(ac4_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac4-silver.parquet")
write_to_csv_s3(ac4_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac4-silver.csv")
destroy_bv(ac4_bv)
print("ac4 completed")

# AC5
print("ac5 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
ac5_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "AC5")
ac5_union_df = union_transform_df(ac5_parquet_df)
ac5_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac5-data-items.txt")
ac5_pivots_df = pivot_transpose_df(ac5_union_df, ac5_bv)
csv_stage_barrier(ac5_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
ac5_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
ac5_typed_df = struct_type_schema_df(ac5_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
write_to_parquet_s3(ac5_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac5-silver.parquet")
write_to_csv_s3(ac5_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac5-silver.csv")
destroy_bv(ac5_bv)
print("ac5 completed")

# end session
session()

# garrett r peternel | spark developer | lm aeronautics