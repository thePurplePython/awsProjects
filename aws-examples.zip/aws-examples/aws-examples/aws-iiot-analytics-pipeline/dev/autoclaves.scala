// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process autoclave device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr}

// repartitioned data location from spark scala job
val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

// read parquet table and filter dataset for specific device
def parquetTransform(path: String, device: String): DataFrame = {
    val parquetDf = spark
    .read
    .parquet(path)
    .select(date_format(col("timestamp"),
                        "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
    .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
    .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
    .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
    .filter((col("deviceName") === device))
    return parquetDf
}

// union values (event, sample, condition) to collect data-item tags
def unionTransform(df: DataFrame): DataFrame = {
    val conditionDf = df
    .withColumnRenamed("valueCondition", "value")
    .filter("category = 'CONDITION'")
    .drop("valueSample", "valueEvent")
    val eventDf = df
    .withColumnRenamed("valueEvent", "value")
    .filter("category = 'EVENT'")
    .drop("valueSample", "valueCondition")
    val sampleDf = df
    .withColumnRenamed("valueSample", "value")
    .filter("category = 'SAMPLE'")
    .drop("valueEvent", "valueCondition")
    val unionDf = conditionDf
    .union(eventDf)
    .union(sampleDf)
    return unionDf
}

// read txt file with distinct data-items and convert to list for broadcast variable
def broadcastTransform(path: String): Broadcast[Array[Any]] = {
    val df = spark
    .read
    .format("csv")
    .option("header", "true")
    .load(path)
    val items = df.rdd.map(x => x(0)).collect()
    val bv = spark.sparkContext.broadcast(items)
    return bv
}

// pivot unique data--item rows to columns
def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
    val pivotDf = df
    .groupBy("timestamp")
    .pivot("dataItemId", bv.value)
    .agg(expr("first(value)"))
    return pivotDf
}

// write to csv for schema inference
def csvStage(df: DataFrame, path: String) {
    return df
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "true")
    .mode("overwrite")
    .save(path)
}

// map schema to df
def inferSchema(path: String): DataFrame = {
    val schemaDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(path)
    return schemaDf
}

// map schema to df
def typedSchema(df: DataFrame, path: String): DataFrame = {
    val schema = df.schema
    val typedDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .schema(schema)
    .load(path)
    return typedDf
}

// write to parquet
def parquetWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("parquet")
    .mode("overwrite")
    .save(path)
}

// write to csv
def csvWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "false")
    .mode("overwrite")
    .save(path)
}

// kill broadcast variable
def bvDestroy(bv: Broadcast[Array[Any]]) {
    return bv.destroy()
}

// end session
def kill() {
    return spark.stop()
}

// AC1
println("ac1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val ac1ParquetDf = parquetTransform(inputPath, "AC1")
val ac1UnionDf = unionTransform(ac1ParquetDf)
val ac1Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac1-data-items.txt")
val ac1PivotsDf = pivotTransform(ac1UnionDf, ac1Bv)
csvStage(ac1PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
val ac1SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
val ac1TypedDf = typedSchema(ac1SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac1-silver.csv")
parquetWrite(ac1TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet")
csvWrite(ac1TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac1-silver.csv")
bvDestroy(ac1Bv)
println("ac1 completed")

// AC2
println("ac2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val ac2ParquetDf = parquetTransform(inputPath, "AC2")
val ac2UnionDf = unionTransform(ac2ParquetDf)
val ac2Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac2-data-items.txt")
val ac2PivotsDf = pivotTransform(ac2UnionDf, ac2Bv)
csvStage(ac2PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
val ac2SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
val ac2TypedDf = typedSchema(ac2SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac2-silver.csv")
parquetWrite(ac2TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac2-silver.parquet")
csvWrite(ac2TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac2-silver.csv")
bvDestroy(ac2Bv)
println("ac2 completed")

// AC3
println("ac3 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val ac3ParquetDf = parquetTransform(inputPath, "AC3")
val ac3UnionDf = unionTransform(ac3ParquetDf)
val ac3Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac3-data-items.txt")
val ac3PivotsDf = pivotTransform(ac3UnionDf, ac3Bv)
csvStage(ac3PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
val ac3SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
val ac3CastDf = (ac3SchemaDf
.withColumn("ac3_event_rawtranscurrdaub", col("ac3_event_rawtranscurrdaub").cast("double"))
.withColumn("ac3_event_rawtranscurr", col("ac3_event_rawtranscurr").cast("double")))
val ac3TypedDf = typedSchema(ac3CastDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac3-silver.csv")
parquetWrite(ac3TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac3-silver.parquet")
csvWrite(ac3TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac3-silver.csv")
bvDestroy(ac3Bv)
println("ac3 completed")

// AC4
println("ac4 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val ac4ParquetDf = parquetTransform(inputPath, "AC_4")
val ac4UnionDf = unionTransform(ac4ParquetDf)
val ac4Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac4-data-items.txt")
val ac4PivotsDf = pivotTransform(ac4UnionDf, ac4Bv)
csvStage(ac4PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
val ac4SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
val ac4TypedDf = typedSchema(ac4SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac4-silver.csv")
parquetWrite(ac4TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac4-silver.parquet")
csvWrite(ac4TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac4-silver.csv")
bvDestroy(ac4Bv)
println("ac4 completed")

// AC5
println("ac5 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val ac5ParquetDf = parquetTransform(inputPath, "AC5")
val ac5UnionDf = unionTransform(ac5ParquetDf)
val ac5Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/ac5-data-items.txt")
val ac5PivotsDf = pivotTransform(ac5UnionDf, ac5Bv)
csvStage(ac5PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
val ac5SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
val ac5TypedDf = typedSchema(ac5SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-ac5-silver.csv")
parquetWrite(ac5TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac5-silver.parquet")
csvWrite(ac5TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-ac5-silver.csv")
bvDestroy(ac5Bv)
println("ac5 completed")

// end session
kill()

// garrett r peternel | spark developer | lm aeronautics