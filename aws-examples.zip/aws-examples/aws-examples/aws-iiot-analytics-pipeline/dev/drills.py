# garrett r peternel | spark developer | lm aeronautics

# *** prototype ***
# summary => transform and pre-process drill device data for feature engineering moodeling
# *** prototype ***

# modules
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

# repartitioned data location from spark scala job
PARQUET_SOURCE_PATH = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

# funcs
def string_replacer(x, y):
    """
    summary => replaces string input with string output
    :x => input string value
    :y => output string value
    """
    return F.when(x != y, x).otherwise(F.lit(None))

def parquet_read_df(PATH="", DEVICE=""):
    """
    summary => read parquet table and filter dataset for specific device
    :PATH => input data path
    :DEVICE => device metadata
    """
    parquet_df = spark\
    .read\
    .parquet(PATH)\
    .select(F.date_format(F.col("timestamp"), "yyyy-MM-dd HH:mm:ss").cast("timestamp").alias("timestamp"),\
            "deviceName",\
            "deviceUuid",\
            "category",\
            F.lower(F.translate(F.col("dataItemId"), ". ", "__")).alias("dataItemId"),\
            "valueCondition",\
            "valueEvent",\
            "valueSample")\
    .withColumn("dataItemId", F.concat(F.lower(F.col("deviceName")), F.lit("_"), F.lower(F.col("category")), F.lit("_"), F.col("dataItemId")))\
    .withColumn("valueCondition", string_replacer(F.col("valueCondition"), ""))\
    .withColumn("valueEvent", string_replacer(F.col("valueEvent"), ""))\
    .filter((F.col("deviceName") == DEVICE))
    return parquet_df

def union_transform_df(df):
    """
    summary => union values (event, sample, condition) to collect data-item tags
    :df => input dataframe
    """
    conditions_df = df\
    .withColumnRenamed("valueCondition", "value")\
    .filter("category = 'CONDITION'")\
    .drop("valueSample", "valueEvent")
    events_df = df\
    .withColumnRenamed("valueEvent", "value")\
    .filter("category = 'EVENT'")\
    .drop("valueSample", "valueCondition")
    samples_df = df\
    .withColumnRenamed("valueSample", "value")\
    .filter("category = 'SAMPLE'")\
    .drop("valueEvent", "valueCondition")
    union_df = conditions_df\
    .union(events_df)\
    .union(samples_df)
    return union_df

def df_to_list_to_bv(PATH=""):
    """
    summary => read txt file with distinct data-items and convert to list for broadcast variable
    :PATH => input file path
    """
    df = spark.read.csv(PATH, header=True)
    items = df.rdd.flatMap(lambda x: x).collect()
    bv = spark.sparkContext.broadcast(items)
    return bv

def pivot_transpose_df(df, bv):
    """
    summary => pivot unique data--item rows to columns
    :df => input dataframe
    :bv => broadcast variable
    """
    pivots_df = df\
    .groupBy("timestamp")\
    .pivot('dataItemId', bv.value)\
    .agg(F.expr("first(value)"))
    return pivots_df

def csv_stage_barrier(df, PATH=""):
    """
    summary => write to csv for schema inference
    : df => input dataframe
    : PATH => input file path
    """
    df\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "true")\
    .mode("overwrite")\
    .save(PATH)

def dynamic_infer_schema_types_df(PATH=""):
    """
    summary => infer types
    : PATH => input file path
    """
    schema_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load(PATH)
    return schema_df

def struct_type_schema_df(df, PATH=""):
    """
    summary => map schema to df
    : df => input dataframe
    : PATH => input file path
    """
    schema = df.schema
    typed_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .schema(schema)\
    .load(PATH)
    return typed_df

def write_to_parquet_s3(df, repartition, PATH=""):
    """
    summary => write to parquet
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("parquet")\
    .mode("overwrite")\
    .save(PATH)

def write_to_csv_s3(df, repartition, PATH=""):
    """
    summary => write to csv
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "false")\
    .mode("overwrite")\
    .save(PATH)

def destroy_bv(bv):
    """
    summary => destrory broadcast variable
    : bv => broadcast variable
    """
    return bv.destroy()

def session():
    """
    summary => end session
    """
    return spark.stop()

# FAD1
print("fad1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
fad1_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FAD_1")
fad1_union_df = union_transform_df(fad1_parquet_df)
fad1_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt")
fad1_pivots_df = pivot_transpose_df(fad1_union_df, fad1_bv)
csv_stage_barrier(fad1_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
fad1_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
fad1_typed_df = struct_type_schema_df(fad1_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
write_to_parquet_s3(fad1_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet")
write_to_csv_s3(fad1_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad1-silver.csv")
destroy_bv(fad1_bv)
print("fad1 completed")

# FAD2
print("fad2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
fad2_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FAD_2")
fad2_union_df = union_transform_df(fad2_parquet_df)
fad2_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad2-data-items.txt")
fad2_pivots_df = pivot_transpose_df(fad2_union_df, fad2_bv)
csv_stage_barrier(fad2_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
fad2_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
fad2_cast_df = fad2_schema_df\
.withColumn("fad_2_sample_bd_energy", F.col("fad_2_sample_bd_energy").cast("double"))\
.withColumn("fad_2_sample_zd_energy", F.col("fad_2_sample_zd_energy").cast("double"))\
.withColumn("fad_2_sample_wd_energy", F.col("fad_2_sample_wd_energy").cast("double"))\
.withColumn("fad_2_sample_ysd_energy", F.col("fad_2_sample_ysd_energy").cast("double"))\
.withColumn("fad_2_sample_t_wd_energy", F.col("fad_2_sample_t_wd_energy").cast("double"))\
.withColumn("fad_2_sample_x2d_energy", F.col("fad_2_sample_x2d_energy").cast("double"))\
.withColumn("fad_2_sample_cd_energy", F.col("fad_2_sample_cd_energy").cast("double"))
fad2_typed_df = struct_type_schema_df(fad2_cast_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
write_to_parquet_s3(fad2_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet")
write_to_csv_s3(fad2_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad2-silver.csv")
destroy_bv(fad2_bv)
print("fad2 completed")

# end session
session()

# garrett r peternel | spark developer | lm aeronautics