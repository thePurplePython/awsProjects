// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process drill device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr}

// repartitioned data location from spark scala job
val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

// read parquet table and filter dataset for specific device
def parquetTransform(path: String, device: String): DataFrame = {
    val parquetDf = spark
    .read
    .parquet(path)
    .select(date_format(col("timestamp"),
                        "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
    .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
    .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
    .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
    .filter((col("deviceName") === device))
    return parquetDf
}

// union values (event, sample, condition) to collect data-item tags
def unionTransform(df: DataFrame): DataFrame = {
    val conditionDf = df
    .withColumnRenamed("valueCondition", "value")
    .filter("category = 'CONDITION'")
    .drop("valueSample", "valueEvent")
    val eventDf = df
    .withColumnRenamed("valueEvent", "value")
    .filter("category = 'EVENT'")
    .drop("valueSample", "valueCondition")
    val sampleDf = df
    .withColumnRenamed("valueSample", "value")
    .filter("category = 'SAMPLE'")
    .drop("valueEvent", "valueCondition")
    val unionDf = conditionDf
    .union(eventDf)
    .union(sampleDf)
    return unionDf
}

// read txt file with distinct data-items and convert to list for broadcast variable
def broadcastTransform(path: String): Broadcast[Array[Any]] = {
    val df = spark
    .read
    .format("csv")
    .option("header", "true")
    .load(path)
    val items = df.rdd.map(x => x(0)).collect()
    val bv = spark.sparkContext.broadcast(items)
    return bv
}

// pivot unique data--item rows to columns
def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
    val pivotDf = df
    .groupBy("timestamp")
    .pivot("dataItemId", bv.value)
    .agg(expr("first(value)"))
    return pivotDf
}

// write to csv for schema inference
def csvStage(df: DataFrame, path: String) {
    return df
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "true")
    .mode("overwrite")
    .save(path)
}

// map schema to df
def inferSchema(path: String): DataFrame = {
    val schemaDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(path)
    return schemaDf
}

// map schema to df
def typedSchema(df: DataFrame, path: String): DataFrame = {
    val schema = df.schema
    val typedDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .schema(schema)
    .load(path)
    return typedDf
}

// write to parquet
def parquetWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("parquet")
    .mode("overwrite")
    .save(path)
}

// write to csv
def csvWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "false")
    .mode("overwrite")
    .save(path)
}

// kill broadcast variable
def bvDestroy(bv: Broadcast[Array[Any]]) {
    return bv.destroy()
}

// end session
def kill() {
    return spark.stop()
}

// FAD1
println("fad1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val fad1ParquetDf = parquetTransform(inputPath, "FAD_1")
val fad1UnionDf = unionTransform(fad1ParquetDf)
val fad1Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt")
val fad1PivotsDf = pivotTransform(fad1UnionDf, fad1Bv)
csvStage(fad1PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
val fad1SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
val fad1TypedDf = typedSchema(fad1SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad1-silver.csv")
parquetWrite(fad1TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet")
csvWrite(fad1TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad1-silver.csv")
bvDestroy(fad1Bv)
println("fad1 completed")

// FAD2
println("fad2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val fad2ParquetDf = parquetTransform(inputPath, "FAD_2")
val fad2UnionDf = unionTransform(fad2ParquetDf)
val fad2Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad2-data-items.txt")
val fad2PivotsDf = pivotTransform(fad2UnionDf, fad2Bv)
csvStage(fad2PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
val fad2SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
val fad2CastDf = (fad2SchemaDf
.withColumn("fad_2_sample_bd_energy", col("fad_2_sample_bd_energy").cast("double"))
.withColumn("fad_2_sample_zd_energy", col("fad_2_sample_zd_energy").cast("double"))
.withColumn("fad_2_sample_wd_energy", col("fad_2_sample_wd_energy").cast("double"))
.withColumn("fad_2_sample_ysd_energy", col("fad_2_sample_ysd_energy").cast("double"))
.withColumn("fad_2_sample_t_wd_energy", col("fad_2_sample_t_wd_energy").cast("double"))
.withColumn("fad_2_sample_x2d_energy", col("fad_2_sample_x2d_energy").cast("double"))
.withColumn("fad_2_sample_cd_energy", col("fad_2_sample_cd_energy").cast("double")))
val fad2TypedDf = typedSchema(fad2CastDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fad2-silver.csv")
parquetWrite(fad2TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet")
csvWrite(fad2TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad2-silver.csv")
bvDestroy(fad2Bv)
println("fad2 completed")

// end session
kill()

// garrett r peternel | spark developer | lm aeronautics