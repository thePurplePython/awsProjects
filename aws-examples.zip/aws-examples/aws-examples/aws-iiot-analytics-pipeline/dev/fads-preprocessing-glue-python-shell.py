import boto3
import pandas as pd
import numpy as np
import io
import re

def header(bucket, key):
    s3_client = boto3.client('s3')
    file = s3_client.get_object(Bucket=bucket, Key=key)
    body = file['Body']
    return body.read().decode('utf-8').split()

def parser_string(match='', col_list=[]):
    r = re.compile(match)
    cols = list(filter(r.match, col_list))
    return cols

def s3_single_csv_file(key, bucket, s3_client=None, **kwargs):
    if s3_client is None:
        s3_client = boto3.client('s3')
    obj = s3_client.get_object(Bucket=bucket, Key=key)
    return pd.read_csv(obj["Body"], **kwargs)

def s3_multi_csv_files(prefix, bucket, s3=None, s3_client=None, **kwargs):
    if not prefix.endswith('/'):
        prefix = prefix + '/'
    if s3_client is None:
        s3_client = boto3.client('s3')
    if s3 is None:
        s3 = boto3.resource('s3')
    s3_keys = [item.key for item in s3.Bucket(bucket).objects.filter(Prefix=prefix) if item.key.endswith('.csv')]
    data = [s3_single_csv_file(key, bucket=bucket, s3_client=s3_client, **kwargs) for key in s3_keys]
    return pd.concat(data, ignore_index=True)

def sortby(df, **kwargs):
    df.sort_values(**kwargs, inplace=True)
    df.reset_index(drop=True, inplace=True)
    df['timestamp'] = pd.to_datetime(df['timestamp'], format='%Y-%m-%d %H:%M:%S')
    df['timestamp'] = df['timestamp'].dt.tz_convert(None)
    df.set_index(['timestamp'], inplace=True)
    return df

def remove_data(df, mask=int):
    df['date'] = df.index.date
    df = df.groupby('date').filter(lambda x: len(x) > mask)
    #df = df.loc[df.groupby('date').date.transform(len) > mask]
    df = df.drop(columns=['date'])
    return df

def imputer(df):
    df.interpolate(method='linear', limit_direction='both', inplace=True)
    return df

def resample(df, freq=''):
    df = df.resample(freq).ffill().bfill()
    df = df.drop_duplicates()
    df.reset_index(inplace=True)
    return df

def ts_to_epoch(df):
    df['timestamp'] = df['timestamp'].astype('int')
    return df

def save_dataframe(df, path):
    return df.to_csv(path, header=False, index=False)
    #return df.to_csv(path, header=True, index=False)
    #np.savetxt('fad2-sample-features.csv.gz', imputer_df, delimiter=',', fmt='%s')
    #boto3.Session().resource('s3').Bucket('aero-iiot').Object(key).upload_file(filename)

if __name__ == "__main__":
    # fad1
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_csv_df = s3_multi_csv_files('datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad1-silver.csv/', 'aero-iiot', delimiter=',', names=lines, usecols=['timestamp'] + cols)
    multi_csv_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_csv_df = sortby(multi_csv_df, by=['timestamp'])
    print(list(sorted_multi_csv_df.columns))
    filter_df = remove_data(sorted_multi_csv_df, 1440)
    imputer_df = imputer(filter_df)
    resample_df = resample(imputer_df, '1min')
    print(resample_df.shape)
    write_df = ts_to_epoch(resample_df)
    save_dataframe(write_df, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/1min-samples/fad1-glue-sample-features.csv')
    del lines
    del cols
    del multi_csv_df
    del sorted_multi_csv_df
    del filter_df
    del imputer_df
    del resample_df

    '''
    # fad2
    lines = header('aero-iiot', 'datasets/e363549/iiot-analytics-pipeline/schemas/fad2-data-items.txt')
    cols = parser_string('.*_sample', lines)
    multi_csv_df = s3_multi_csv_files('datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fad2-silver.csv/', 'aero-iiot', delimiter=',', names=lines, usecols=['timestamp'] + cols)
    multi_csv_df.dropna(axis=1, how='all', inplace=True)
    sorted_multi_csv_df = sortby(multi_csv_df, by=['timestamp'])
    print(list(sorted_multi_csv_df.columns))
    filter_df = remove_data(sorted_multi_csv_df, 1440)
    imputer_df = imputer(filter_df)
    resample_df = resample(imputer_df, '1min')
    print(resample_df.shape)
    write_df = ts_to_epoch(resample_df)
    save_dataframe(write_df, 's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/1min-samples/fad2-glue-sample-features.csv')
    del lines
    del cols
    del multi_csv_df
    del sorted_multi_csv_df
    del filter_df
    del imputer_df
    del resample_df
    '''