# garrett r peternel | spark developer | lm aeronautics

# *** prototype ***
# summary => transform and pre-process mill device data for feature engineering moodeling
# *** prototype ***

# modules
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

# repartitioned data location from spark scala job
PARQUET_SOURCE_PATH = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

# funcs
def string_replacer(x, y):
    """
    summary => replaces string input with string output
    :x => input string value
    :y => output string value
    """
    return F.when(x != y, x).otherwise(F.lit(None))

def parquet_read_df(PATH="", DEVICE=""):
    """
    summary => read parquet table and filter dataset for specific device
    :PATH => input data path
    :DEVICE => device metadata
    """
    parquet_df = spark\
    .read\
    .parquet(PATH)\
    .select(F.date_format(F.col("timestamp"), "yyyy-MM-dd HH:mm:ss").cast("timestamp").alias("timestamp"),\
            "deviceName",\
            "deviceUuid",\
            "category",\
            F.lower(F.translate(F.col("dataItemId"), ". ", "__")).alias("dataItemId"),\
            "valueCondition",\
            "valueEvent",\
            "valueSample")\
    .withColumn("dataItemId", F.concat(F.lower(F.col("deviceName")), F.lit("_"), F.lower(F.col("category")), F.lit("_"), F.col("dataItemId")))\
    .withColumn("valueCondition", string_replacer(F.col("valueCondition"), ""))\
    .withColumn("valueEvent", string_replacer(F.col("valueEvent"), ""))\
    .filter((F.col("deviceName") == DEVICE))
    return parquet_df

def union_transform_df(df):
    """
    summary => union values (event, sample, condition) to collect data-item tags
    :df => input dataframe
    """
    conditions_df = df\
    .withColumnRenamed("valueCondition", "value")\
    .filter("category = 'CONDITION'")\
    .drop("valueSample", "valueEvent")
    events_df = df\
    .withColumnRenamed("valueEvent", "value")\
    .filter("category = 'EVENT'")\
    .drop("valueSample", "valueCondition")
    samples_df = df\
    .withColumnRenamed("valueSample", "value")\
    .filter("category = 'SAMPLE'")\
    .drop("valueEvent", "valueCondition")
    union_df = conditions_df\
    .union(events_df)\
    .union(samples_df)
    return union_df

def df_to_list_to_bv(PATH=""):
    """
    summary => read txt file with distinct data-items and convert to list for broadcast variable
    :PATH => input file path
    """
    df = spark.read.csv(PATH, header=True)
    items = df.rdd.flatMap(lambda x: x).collect()
    bv = spark.sparkContext.broadcast(items)
    return bv

def pivot_transpose_df(df, bv):
    """
    summary => pivot unique data--item rows to columns
    :df => input dataframe
    :bv => broadcast variable
    """
    pivots_df = df\
    .groupBy("timestamp")\
    .pivot('dataItemId', bv.value)\
    .agg(F.expr("first(value)"))
    return pivots_df

def csv_stage_barrier(df, PATH=""):
    """
    summary => write to csv for schema inference
    : df => input dataframe
    : PATH => input file path
    """
    df\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "true")\
    .mode("overwrite")\
    .save(PATH)

def dynamic_infer_schema_types_df(PATH=""):
    """
    summary => infer types
    : PATH => input file path
    """
    schema_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .option("inferSchema", "true")\
    .load(PATH)
    return schema_df

def struct_type_schema_df(df, PATH=""):
    """
    summary => map schema to df
    : df => input dataframe
    : PATH => input file path
    """
    schema = df.schema
    typed_df = spark\
    .read\
    .format("csv")\
    .option("header", "true")\
    .schema(schema)\
    .load(PATH)
    return typed_df

def write_to_parquet_s3(df, repartition, PATH=""):
    """
    summary => write to parquet
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("parquet")\
    .mode("overwrite")\
    .save(PATH)

def write_to_csv_s3(df, repartition, PATH=""):
    """
    summary => write to csv
    : df => input dataframe
    : repartition => output files
    : PATH => input file path
    """
    df\
    .repartition(repartition)\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .format("csv")\
    .option("header", "false")\
    .mode("overwrite")\
    .save(PATH)

def destroy_bv(bv):
    """
    summary => destrory broadcast variable
    : bv => broadcast variable
    """
    return bv.destroy()

def session():
    """
    summary => end session
    """
    return spark.stop()

# FOG1
print("fog1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
fog1_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FOG_1")
fog1_union_df = union_transform_df(fog1_parquet_df)
fog1_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog1-data-items.txt")
fog1_pivots_df = pivot_transpose_df(fog1_union_df, fog1_bv)
csv_stage_barrier(fog1_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
fog1_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
fog1_typed_df = struct_type_schema_df(fog1_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
write_to_parquet_s3(fog1_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog1-silver.parquet")
write_to_csv_s3(fog1_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog1-silver.csv")
destroy_bv(fog1_bv)
print("fog1 completed")

# FOG2
print("fog2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
fog2_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FOG_2")
fog2_union_df = union_transform_df(fog2_parquet_df)
fog2_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog2-data-items.txt")
fog2_pivots_df = pivot_transpose_df(fog2_union_df, fog2_bv)
csv_stage_barrier(fog2_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
fog2_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
fog2_typed_df = struct_type_schema_df(fog2_schema_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
write_to_parquet_s3(fog2_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog2-silver.parquet")
write_to_csv_s3(fog2_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog2-silver.csv")
destroy_bv(fog2_bv)
print("fog2 completed")

# DIAMONDNORTH
print("dnorth started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
dnorth_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "DIAMOND_NORTH")
dnorth_union_df = union_transform_df(dnorth_parquet_df)
dnorth_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-north-data-items.txt")
dnorth_pivots_df = pivot_transpose_df(dnorth_union_df, dnorth_bv)
csv_stage_barrier(dnorth_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
dnorth_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
dnorth_cast_df = dnorth_schema_df\
.withColumn("diamond_north_sample_y_m_motor_energy", F.col("diamond_north_sample_y_m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_sp_m_motor_energy", F.col("diamond_north_sample_sp_m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_z_m_motor_energy", F.col("diamond_north_sample_z_m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_x_m_motor_energy", F.col("diamond_north_sample_x_m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_tc_1m_motor_energy", F.col("diamond_north_sample_tc_1m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_a_m_motor_energy", F.col("diamond_north_sample_a_m_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_x_sm_motor_energy", F.col("diamond_north_sample_x_sm_motor_energy").cast("double"))\
.withColumn("diamond_north_sample_c_m_motor_energy", F.col("diamond_north_sample_c_m_motor_energy").cast("double"))
dnorth_typed_df = struct_type_schema_df(dnorth_cast_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
write_to_parquet_s3(dnorth_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-north-silver.parquet")
write_to_csv_s3(dnorth_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-north-silver.csv")
destroy_bv(dnorth_bv)
print("dnorth completed")

# DIAMONDSOUTH
print("dsouth started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
dsouth_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "DIAMOND_SOUTH")
dsouth_union_df = union_transform_df(dsouth_parquet_df)
dsouth_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-south-data-items.txt")
dsouth_pivots_df = pivot_transpose_df(dsouth_union_df, dsouth_bv)
csv_stage_barrier(dsouth_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
dsouth_schema_df = dynamic_infer_schema_types_df("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
dsouth_cast_df = dsouth_schema_df\
.withColumn("diamond_south_sample_x_sm_motor_energy", F.col("diamond_south_sample_x_sm_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_c_m_motor_energy", F.col("diamond_south_sample_c_m_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_z_m_motor_energy", F.col("diamond_south_sample_z_m_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_sp_m_motor_energy", F.col("diamond_south_sample_sp_m_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_x_m_motor_energy", F.col("diamond_south_sample_x_m_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_a_m_motor_energy", F.col("diamond_south_sample_a_m_motor_energy").cast("double"))\
.withColumn("diamond_south_sample_y_m_motor_energy", F.col("diamond_south_sample_y_m_motor_energy").cast("double"))
dsouth_typed_df = struct_type_schema_df(dsouth_cast_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
write_to_parquet_s3(dsouth_typed_df, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-south-silver.parquet")
write_to_csv_s3(dsouth_typed_df, 36, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-south-silver.csv")
destroy_bv(dsouth_bv)
print("dsouth completed")

# end session
session()

# garrett r peternel | spark developer | lm aeronautics