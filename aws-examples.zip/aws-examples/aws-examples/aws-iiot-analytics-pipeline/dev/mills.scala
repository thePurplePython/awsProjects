// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => transform and pre-process autoclave device data for feature engineering moodeling
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.functions.{date_format, concat, lower, col, expr}

// repartitioned data location from spark scala job
val inputPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

// read parquet table and filter dataset for specific device
def parquetTransform(path: String, device: String): DataFrame = {
    val parquetDf = spark
    .read
    .parquet(path)
    .select(date_format(col("timestamp"),
                        "yyyy-MM-dd HH:mm:ss")
            .cast("timestamp")
            .as("timestamp"),
            $"deviceName",
            $"deviceUuid",
            $"category",
            lower(translate(col("dataItemId"), ". ", "__")).as("dataItemId"),
            $"valueCondition",
            $"valueEvent",
            $"valueSample")
    .withColumn("dataItemId", concat(lower(col("deviceName")), lit("_"), lower(col("category")), lit("_"), col("dataItemId")))
    .withColumn("valueCondition", when($"valueCondition" !== "", $"valueCondition"))
    .withColumn("valueEvent", when($"valueEvent" !== "", $"valueEvent"))
    .filter((col("deviceName") === device))
    return parquetDf
}

// union values (event, sample, condition) to collect data-item tags
def unionTransform(df: DataFrame): DataFrame = {
    val conditionDf = df
    .withColumnRenamed("valueCondition", "value")
    .filter("category = 'CONDITION'")
    .drop("valueSample", "valueEvent")
    val eventDf = df
    .withColumnRenamed("valueEvent", "value")
    .filter("category = 'EVENT'")
    .drop("valueSample", "valueCondition")
    val sampleDf = df
    .withColumnRenamed("valueSample", "value")
    .filter("category = 'SAMPLE'")
    .drop("valueEvent", "valueCondition")
    val unionDf = conditionDf
    .union(eventDf)
    .union(sampleDf)
    return unionDf
}

// read txt file with distinct data-items and convert to list for broadcast variable
def broadcastTransform(path: String): Broadcast[Array[Any]] = {
    val df = spark
    .read
    .format("csv")
    .option("header", "true")
    .load(path)
    val items = df.rdd.map(x => x(0)).collect()
    val bv = spark.sparkContext.broadcast(items)
    return bv
}

// pivot unique data--item rows to columns
def pivotTransform(df: DataFrame, bv: Broadcast[Array[Any]]): DataFrame = {
    val pivotDf = df
    .groupBy("timestamp")
    .pivot("dataItemId", bv.value)
    .agg(expr("first(value)"))
    return pivotDf
}

// write to csv for schema inference
def csvStage(df: DataFrame, path: String) {
    return df
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "true")
    .mode("overwrite")
    .save(path)
}

// map schema to df
def inferSchema(path: String): DataFrame = {
    val schemaDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .option("inferSchema", "true")
    .load(path)
    return schemaDf
}

// map schema to df
def typedSchema(df: DataFrame, path: String): DataFrame = {
    val schema = df.schema
    val typedDf = spark
    .read
    .format("csv")
    .option("header", "true")
    .schema(schema)
    .load(path)
    return typedDf
}

// write to parquet
def parquetWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("parquet")
    .mode("overwrite")
    .save(path)
}

// write to csv
def csvWrite(df: DataFrame, repartition: Int, path: String) {
    return df
    .repartition(repartition)
    .sortWithinPartitions(col("timestamp"))
    .write
    .format("csv")
    .option("header", "false")
    .mode("overwrite")
    .save(path)
}

// kill broadcast variable
def bvDestroy(bv: Broadcast[Array[Any]]) {
    return bv.destroy()
}

// end session
def kill() {
    return spark.stop()
}

// FOG1
println("fog1 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val fog1ParquetDf = parquetTransform(inputPath, "FOG_1")
val fog1UnionDf = unionTransform(fog1ParquetDf)
val fog1Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog1-data-items.txt")
val fog1PivotsDf = pivotTransform(fog1UnionDf, fog1Bv)
csvStage(fog1PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
val fog1SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
val fog1TypedDf = typedSchema(fog1SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog1-silver.csv")
parquetWrite(fog1TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog1-silver.parquet")
csvWrite(fog1TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog1-silver.csv")
bvDestroy(fog1Bv)
println("fog1 completed")

// FOG2
println("fog2 started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val fog2ParquetDf = parquetTransform(inputPath, "FOG_2")
val fog2UnionDf = unionTransform(fog2ParquetDf)
val fog2Bv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fog2-data-items.txt")
val fog2PivotsDf = pivotTransform(fog2UnionDf, fog2Bv)
csvStage(fog2PivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
val fog2SchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
val fog2TypedDf = typedSchema(fog2SchemaDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-fog2-silver.csv")
parquetWrite(fog2TypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog2-silver.parquet")
csvWrite(fog2TypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-fog2-silver.csv")
bvDestroy(fog2Bv)
println("fog2 completed")

// DIAMOND NORTH
println("dnorth started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val dnorthParquetDf = parquetTransform(inputPath, "DIAMOND_NORTH")
val dnorthUnionDf = unionTransform(dnorthParquetDf)
val dnorthBv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-north-data-items.txt")
val dnorthPivotsDf = pivotTransform(dnorthUnionDf, dnorthBv)
csvStage(dnorthPivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
val dnorthSchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
val dnorthCastDf = (dnorthSchemaDf
.withColumn("diamond_north_sample_y_m_motor_energy", col("diamond_north_sample_y_m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_sp_m_motor_energy", col("diamond_north_sample_sp_m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_z_m_motor_energy", col("diamond_north_sample_z_m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_x_m_motor_energy", col("diamond_north_sample_x_m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_tc_1m_motor_energy", col("diamond_north_sample_tc_1m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_a_m_motor_energy", col("diamond_north_sample_a_m_motor_energy").cast("double"))
.withColumn("diamond_north_sample_x_sm_motor_energy", col("diamond_north_sample_x_sm_motor_energy").cast("double"))
.withColumn("diamond_north_sample_c_m_motor_energy", col("diamond_north_sample_c_m_motor_energy").cast("double")))
val dnorthTypedDf = typedSchema(dnorthCastDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-north-silver.csv")
parquetWrite(dnorthTypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-north-silver.parquet")
csvWrite(dnorthTypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-north-silver.csv")
bvDestroy(dnorthBv)
println("dnorth completed")

// DIAMOND SOUTH
println("dsouth started")
spark.conf.set("spark.sql.shuffle.partitions", 256)
val dsouthParquetDf = parquetTransform(inputPath, "DIAMOND_SOUTH")
val dsouthUnionDf = unionTransform(dsouthParquetDf)
val dsouthBv = broadcastTransform("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/diamond-south-data-items.txt")
val dsouthPivotsDf = pivotTransform(dsouthUnionDf, dsouthBv)
csvStage(dsouthPivotsDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
val dsouthSchemaDf = inferSchema("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
val dsouthCastDf = (dsouthSchemaDf
.withColumn("diamond_south_sample_x_sm_motor_energy", col("diamond_south_sample_x_sm_motor_energy").cast("double"))
.withColumn("diamond_south_sample_c_m_motor_energy", col("diamond_south_sample_c_m_motor_energy").cast("double"))
.withColumn("diamond_south_sample_z_m_motor_energy", col("diamond_south_sample_z_m_motor_energy").cast("double"))
.withColumn("diamond_south_sample_sp_m_motor_energy", col("diamond_south_sample_sp_m_motor_energy").cast("double"))
.withColumn("diamond_south_sample_x_m_motor_energy", col("diamond_south_sample_x_m_motor_energy").cast("double"))
.withColumn("diamond_south_sample_a_m_motor_energy", col("diamond_south_sample_a_m_motor_energy").cast("double"))
.withColumn("diamond_south_sample_y_m_motor_energy", col("diamond_south_sample_y_m_motor_energy").cast("double")))
val dsouthTypedDf = typedSchema(dsouthCastDf, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/stage/pivot-s3-stage-diamond-south-silver.csv")
parquetWrite(dsouthTypedDf, 8, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-south-silver.parquet")
csvWrite(dsouthTypedDf, 50, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/csv/pivot-s3-csv-diamond-south-silver.csv")
bvDestroy(dsouthBv)
println("dsouth completed")

// end session
kill()

// garrett r peternel | spark developer | lm aeronautics