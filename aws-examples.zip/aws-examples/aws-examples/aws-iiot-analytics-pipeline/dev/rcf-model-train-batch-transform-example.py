#https://forums.aws.amazon.com/thread.jspa?threadID=287303
#https://github.com/awslabs/amazon-sagemaker-examples/blob/master/introduction_to_amazon_algorithms/random_cut_forest/random_cut_forest.ipynb
#https://aws.amazon.com/blogs/machine-learning/associating-prediction-results-with-input-data-using-amazon-sagemaker-batch-transform/

import boto3
import os
import io
import numpy as np
import pandas as pd
from datetime import datetime
import sagemaker
from sagemaker import RandomCutForest
from sagemaker import get_execution_role
from sagemaker.amazon.amazon_estimator import get_image_uri
from sagemaker import RandomCutForest
from sagemaker import Model
from time import gmtime, strftime
sagemaker_session = sagemaker.Session()
role = get_execution_role()
region_name = boto3.Session().region_name

def rcf(base_job_name=str,\
        #s3_train_data=str,\
        path=str,\
        output_path=str,\
        train_instance_count=int,\
        train_instance_type=str,\
        num_samples_per_tree=int,\
        #feature_dim=int,\
        num_trees=int):
    
    sagemaker_session = sagemaker.Session()
    role = get_execution_role()
    #container = sagemaker.amazon.amazon_estimator.get_image_uri(region_name, "randomcutforest", "latest")
    
    df = pd.read_csv(path, header=None)
    
    rcf_model = RandomCutForest(
        #container,
        role=role,
        output_path=output_path,
        train_instance_count=train_instance_count,
        train_instance_type=train_instance_type,
        num_samples_per_tree=num_samples_per_tree,
        num_trees=num_trees,\
        sagemaker_session=sagemaker_session,
        base_job_name=base_job_name + strftime("%Y-%m-%d-%H-%M-%S", gmtime()))
    
    return rcf_model.fit(rcf_model.record_set(df.drop(df.columns[0], axis=1).values))

'''
    rcf_model.set_hyperparameters(
        num_samples_per_tree=num_samples_per_tree,
        num_trees=num_trees,
        feature_dim=feature_dim)

    s3_train_input = sagemaker.session.s3_input(
        s3_train_data,
        distribution='ShardedByS3Key',
        content_type='text/csv;label_size=0')
    
    return rcf_model.fit({'train': s3_train_input})
'''

rcf('ac1-rcf-samples-1-min-granularity-',\
    's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/1min-samples/ac1-sample-features.csv',\
    's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/artifacts/ac1/',\
    1,\
    'ml.m5.2xlarge',\
    512,\
    100)

def rcf_transform(model_data=str,\
                  instance_count=int,\
                  instance_type=str,\
                  output_path=str,\
                  input_location=str,\
                  input_filter=str,\
                  output_filter=str,\
                  job_name=str):
    
    model = Model(model_data=model_data,
                  image=sagemaker.amazon.amazon_estimator.get_image_uri(region_name, "randomcutforest", "latest"),
                  role=get_execution_role())
    
    rcf_transformer = model.transformer(instance_count=instance_count,
                                        instance_type=instance_type,
                                        accept='text/csv',
                                        assemble_with='Line',
                                        output_path=output_path)
    
    rcf_transformer.transform(input_location,
                              input_filter=input_filter,
                              output_filter=output_filter,
                              join_source='Input',
                              content_type='text/csv',
                              split_type='Line',
                              job_name=job_name + strftime("%Y-%m-%d-%H-%M-%S", gmtime()))
    
    rcf_transformer.wait()

rcf_transform('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/artifacts/ac1/ac1-rcf-samples-1-min-granularity-2020--2020-05-14-15-44-41-035/output/model.tar.gz',\
              1,\
              'ml.m5.2xlarge',\
              's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac1/',\
              's3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/gold/1min-samples/ac1-sample-features.csv',\
              '$[1:]',\
              '$[0,-1]',\
              'ac1-rcf-results-1-min-granularity-')
