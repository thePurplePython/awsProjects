import pandas as pd
import numpy as np

'''
df = pd.read_csv('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac1/ac1-sample-features.csv.out', header=None)
df.columns = ['timestamp', 'score']
df['timestamp'] = pd.to_datetime(df['timestamp'], unit = 'ns')
df['device'] = 'AC1'

score_mean = df['score'].mean()
score_std = df['score'].std()
score_cutoff = score_mean + 3*score_std
df['anomaly'] = np.where(df['score']>score_cutoff, 1, 0)
'''

def post_processing_anomalies(PATH, FLAG):
    df = pd.read_csv(PATH, header=None)
    df.columns = ['timestamp', 'score']
    df['timestamp'] = pd.to_datetime(df['timestamp'], unit = 'ns')
    df['device'] = FLAG
    score_mean = df['score'].mean()
    score_std = df['score'].std()
    score_cutoff = score_mean + 3*score_std
    df['anomaly'] = np.where(df['score']>score_cutoff, 1, 0)
    return df

ac1 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac1/ac1-sample-features.csv.out', 'AC1')
ac2 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac2/ac2-sample-features.csv.out', 'AC2')
ac3 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac3/ac3-sample-features.csv.out', 'AC3')
ac4 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac4/ac4-sample-features.csv.out', 'AC_4')
ac5 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/ac5/ac5-sample-features.csv.out', 'AC5')
fad1 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/fad1/fad1-sample-features.csv.out', 'FAD_1')
fad2 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/fad2/fad2-sample-features.csv.out', 'FAD_2')
dn = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/diamond-north/diamond-north-sample-features.csv.out', 'DIAMOND_NORTH')
ds = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/diamond-south/diamond-south-sample-features.csv.out', 'DIAMOND_SOUTH')
fog1 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/fog1/fog1-sample-features.csv.out', 'FOG_1')
fog2 = post_processing_anomalies('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/fog2/fog2-sample-features.csv.out', 'FOG_2')

pdf = pd.concat([ac1, ac2, ac3, ac4, ac5, fad1, fad2, dn, ds, fog1, fog2])
pdf = pdf.sort_values(by='timestamp')
pdf.count()

import s3fs
bytes_to_write = pdf.to_csv(index=False, header=True).encode()
fs = s3fs.S3FileSystem()
with fs.open('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/concat/anomalies.csv', 'wb') as f:
    f.write(bytes_to_write)

test = pd.read_csv('s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/results/concat/anomalies.csv')
test.count()

test.head(10)
test.anomaly.value_counts()