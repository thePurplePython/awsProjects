// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => repartition data to optimize file size
// *** prototype ***

// spark-submit --deploy-mode cluster 

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{add_months, current_date, desc, to_date}
import org.apache.spark.util.SizeEstimator

/*
1 master => r5d.4xlarge
4 slaves  => r5d.4xlarge
*/

//.config("spark.submit.deployMode","cluster")

// access keys if needed
// spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "")
// spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "")

// paths
val baseHistoricPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/historical-stream-s3-parquet-sink-iron.parquet/"
val basePath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/stream-s3-parquet-sink-iron.parquet/"
val targetPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

def readHistoricParquet(baseHistoricPath: String, mask: Int): DataFrame = {
    val filterDf = spark
    .read
    .parquet(baseHistoricPath)
    .filter(col("timestamp") >= add_months(current_date(), mask))
    return filterDf
}

def readParquet(basePath: String, mask: Int): DataFrame = {
    val filterDf = spark
    .read
    .parquet(basePath)
    .filter(col("timestamp") >= add_months(current_date(), mask))
    return filterDf
}

def union(df1: DataFrame, df2: DataFrame): DataFrame = {
    val unionDf = df1.union(df2).dropDuplicates()
    return unionDf
}
        
def shuffles(partitions: Int): Unit = {
    return spark.conf.set("spark.sql.shuffle.partitions", partitions)
        }

def num(df: DataFrame): Int = {
    val numPartitions = df.rdd.getNumPartitions
    return numPartitions
}

def megabytes(size: Int): Int = {
    val sizeDf = size
    return sizeDf
}
        
def files(file: Int): Int = {
    val fileDf = file
    return fileDf
}

def dp(): Int = {
    val defaultParallelism  = spark.sparkContext.defaultParallelism
    return defaultParallelism
}

def max(dp: Int, multiplier: Int, size: Int, file: Int): Int = {
    val maxDf = Math.max(dp * multiplier, Math.ceil(size / file).toInt)
    return maxDf
}

def split(df: DataFrame, max: Int): DataFrame = {
    val repartitionDf = df.repartition(max)
    return repartitionDf
}

def writeParquet(df: DataFrame, targetPath: String) {
    return df.write.format("parquet").mode("overwrite").save(targetPath)
}

def kill(): Unit = {
    return spark.stop()
}

val historyDf = readHistoricParquet(baseHistoricPath, -16)
val filterDf = readParquet(basePath, -12)
shuffles(2001)
val unionDf = union(historyDf, filterDf)
val numPartitions = num(unionDf)
val sizeDf = megabytes(300000)
val fileDf = files(128)
val defaultParallelism = dp()
val maxDf = max(defaultParallelism, 3, sizeDf, fileDf)
val repartitionDf = split(unionDf, maxDf)
writeParquet(repartitionDf, targetPath)
kill()

// tuning
spark.conf.set("spark.sql.shuffle.partitions", 2001)
val filterHistoricDf = readParquet(baseHistoricPath, -16)
val filterDf = readParquet(basePath, -12)
val unionDf = union(filterHistoricDf, filterDf)
//spark.conf.set("spark.sql.shuffle.partitions", 8)
//val numberPartitions = filterDf.rdd.getNumPartitions
//val dfSize = 200000 // df approx size (mb cached in RAM)
//val dfPartitionSize = dfSize / numberPartitions
//val newPartitionSize = 128
//val defaultParallelism = spark.sparkContext.defaultParallelism
//val numPartitions = Math.max(defaultParallelism * 2, Math.ceil(dfSize / newPartitionSize).toInt)
//val repartitionDf = filterDf.repartition(numPartitions)
//writeParquet(repartitionDf, "parquet", targetPath)

// end session
spark.stop()

//val optDf : Long = SizeEstimator.estimate(filterDf.rdd)
//val numPartitions : Long = (optDf/134217728) + 1
//val repartitionDf = filterDf.repartition(numPartitions.toInt)


// garrett r peternel | spark developer | lm aeronautics