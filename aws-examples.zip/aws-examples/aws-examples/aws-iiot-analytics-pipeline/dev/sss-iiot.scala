// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => take streaming data from source and feed into mini-batch continuous application
//            to reduce down small files and batch up data into larger files for better performance
//            storage cost ... also flatten out multi-nested json schema for normalized structure
// *** prototype ***

// spark-submit --deploy-mode cluster 

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.functions.{explode}
import org.apache.spark.sql.types.{StructType, StringType, ArrayType, LongType, TimestampType, BooleanType, DoubleType, DateType}

/*
1 master => r5d.4xlarge
4 slaves  => r5d.4xlarge
*/

//.config("spark.submit.deployMode","cluster")

// access keys if needed
// spark.sparkContext.hadoopConfiguration.set("fs.s3a.access.key", "")
// spark.sparkContext.hadoopConfiguration.set("fs.s3a.secret.key", "")

// paths
val basePath = "s3://aero-iiot/datasets/greengrass/historical/"
val checkpointPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/logs/historical-stream-s3-parquet-sink-iron-cp"
val targetPath = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/iron/historical-stream-s3-parquet-sink-iron.parquet"

// schema json mapping
val schema = (new StructType()
              .add("entity", new StructType()
                  .add("header", new StructType()
                       .add("agentBufferSize", StringType, true)
                       .add("agentVersion", StringType, true)
                       .add("collectorVersion", StringType, true)
                       .add("creationTime", StringType, true)
                       .add("deviceName", StringType, true)
                       .add("deviceUuid", StringType, true)
                       .add("instanceId", StringType, true)
                       .add("schemaVersion", StringType, true)
                       .add("sender", StringType, true)))
              .add("observations", ArrayType(new StructType()
                  .add("entity", new StructType()
                          .add("observation", new StructType()
                          .add("category", StringType, true)
                          .add("dataItemId", StringType, true)
                          .add("dataItemName", StringType, true)
                          .add("dataItemPath", ArrayType(new StructType()
                              .add("Actuator", StringType, true)
                              .add("Axes", StringType, true)
                              .add("Controller", StringType, true)
                              .add("Coolant", StringType, true)
                              .add("Device", StringType, true)
                              .add("Linear", StringType, true)
                              .add("Path", StringType, true)
                              .add("Rotary", StringType, true)))
                       .add("dataItemType", StringType, true)
                            .add("dimensions", new StructType()
                                .add("receivedAt", StringType, true)
                                .add("sequence", LongType, true)
                                .add("timestamp", TimestampType, true)
                                .add("unavailable", BooleanType, true))
                       .add("measurements", new StructType()
                           .add("valueCondition", StringType, true)
                           .add("valueEvent", StringType, true)
                           .add("valueSample", DoubleType, true))
                       .add("nativeUnits", StringType, true)
                       .add("subType", StringType, true)
                       .add("units", StringType, true)))))
              .add("type", StringType, true)
              .add("date", DateType, true))

// 1st flattening layer
def readRawJsonStream(basePath: String, maxFilesPerTrigger: Int): DataFrame = {
    val obs_df = spark
    .readStream
    .option("maxFilesPerTrigger", maxFilesPerTrigger)
    .option("latestFirst", true)
    .schema(schema)
    .json(basePath)
    .select($"entity.header.*", explode($"observations.entity.observation").as("obs"))
    return obs_df
}

// 2nd flattening layer
def readRawJsonStreamFlatten(df: DataFrame): DataFrame = {
    val flatten_df = df
    .select($"*", $"obs.*").drop("obs")
    return flatten_df
}

// 3rd flattening layer
def readRawJsonStreamFlattenStruct(df: DataFrame): DataFrame = {
    val flatten_structs_df = df
    .select($"*", $"dimensions.*", $"measurements.*", explode($"dataItemPath").as("path"))
    .drop("dimensions", "measurements", "dataItemPath")
    return flatten_structs_df
}

// 4th flattening layer
def readRawJsonStreamNormalize(df: DataFrame): DataFrame = {
    val normalize_df = df
    .select($"*", $"path.*").drop("path")
    return normalize_df
}

// file sink trigger
def readRawJsonStreamTrigger(df: DataFrame, repartition: Int, checkpointPath: String, trigger: String, format: String): StreamingQuery = {
    val trigger_df = df
    .repartition(repartition)
    .writeStream
    .option("checkpointLocation", checkpointPath)
    .trigger(Trigger.ProcessingTime(trigger))
    .option("path", targetPath)
    .format(format)
    .outputMode("append")
    .start()
    trigger_df.awaitTermination()
    return trigger_df
}

// exec functions
val obs_df = readRawJsonStream(basePath, 25)
val flatten_df = readRawJsonStreamFlatten(obs_df)
val flatten_structs_df = readRawJsonStreamFlattenStruct(flatten_df)
spark.conf.set("spark.sql.shuffle.partitions", 2001)
val normalize_df = readRawJsonStreamNormalize(flatten_structs_df)
val trigger_df = readRawJsonStreamTrigger(normalize_df, 8, checkpointPath, "120 seconds", "parquet")

// spark.streams.active
// Thread.sleep(1200)
// trigger_df.stop()
// spark.stop()
// garrett r peternel | spark developer | lm aeronautics


