# garrett r peternel | spark developer | lm aeronautics

# *** prototype ***
# summary => transform and pre-process drill device data into train and test set for feature engineering moodeling
# *** prototype ***

# modules
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import Window

# 1 master => r5d.4xlarge
# 4 slaves  => r5d.4xlarge

# repartitioned data location from spark scala job
PARQUET_SOURCE_PATH = "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/bronze/repartition-s3-parquet-filter-bronze.parquet"

# funcs
def string_replacer(x, y):
    """
    summary => replaces string input with string output
    :x => input string value
    :y => output string value
    """
    return F.when(x != y, x).otherwise(F.lit(None))

def parquet_read_df(PATH="", DEVICE=""):
    """
    summary => read parquet table and filter dataset for specific device
    :PATH => input data path
    :DEVICE => device metadata
    """
    parquet_df = spark\
    .read\
    .parquet(PATH)\
    .select(F.date_format(F.col("timestamp"), "yyyy-MM-dd HH:mm:ss").cast("timestamp").alias("timestamp"),\
            "deviceName",\
            "deviceUuid",\
            "category",\
            F.lower(F.translate(F.col("dataItemId"), ". ", "__")).alias("dataItemId"),\
            "valueCondition",\
            "valueEvent",\
            "valueSample")\
    .withColumn("dataItemId", F.concat(F.lower(F.col("deviceName")), F.lit("_"), F.lower(F.col("category")), F.lit("_"), F.col("dataItemId")))\
    .withColumn("valueCondition", string_replacer(F.col("valueCondition"), ""))\
    .withColumn("valueEvent", string_replacer(F.col("valueEvent"), ""))\
    .filter((F.col("deviceName") == DEVICE))
    return parquet_df

def union_transform_df(df):
    """
    summary => union values (event, sample, condition) to collect data-item tags
    :df => input dataframe
    """
    conditions_df = df\
    .withColumnRenamed("valueCondition", "value")\
    .filter("category = 'CONDITION'")\
    .drop("valueSample", "valueEvent")
    events_df = df\
    .withColumnRenamed("valueEvent", "value")\
    .filter("category = 'EVENT'")\
    .drop("valueSample", "valueCondition")
    samples_df = df\
    .withColumnRenamed("valueSample", "value")\
    .filter("category = 'SAMPLE'")\
    .drop("valueEvent", "valueCondition")
    union_df = conditions_df\
    .union(events_df)\
    .union(samples_df)
    return union_df

def df_to_list_to_bv(PATH=""):
    """
    summary => read txt file with distinct data-items and convert to list for broadcast variable
    :PATH => input file path
    """
    #import pandas as pd
    #import s3fs
    #df = pd.read_csv(PATH)
    #items = df.values.flatten().tolist()
    df = spark.read.csv(PATH, header=True)
    items = df.rdd.flatMap(lambda x: x).collect()
    bv = spark.sparkContext.broadcast(items)
    return bv

def pivot_transpose_df(df, bv):
    """
    summary => pivot unique data--item rows to columns
    :df => input dataframe
    :bv => broadcast variable
    """
    pivots_df = df\
    .groupBy("timestamp")\
    .pivot('dataItemId', bv.value)\
    .agg(F.expr("first(value)"))\
    .orderBy("timestamp")
    return pivots_df

def ml_split_df(df):
    """
    summary => order dataset for ml split
    :df => input dataframe
    """
    split_df = df\
    .withColumn("rank", F.percent_rank().over(Window.partitionBy().orderBy("timestamp")))
    train_df = split_df.where("rank <= .9").drop("rank")
    test_df = split_df.where("rank > .9").drop("rank")
    return train_df, test_df

def write_train_to_s3(df, PATH=""):
    """
    summary => train dataset split
    :df => input dataframe
    :PATH => dataset path
    """
    df\
    .coalesce(1)\
    .write\
    .mode("overwrite")\
    .format("parquet")\
    .save(PATH)

def write_test_to_s3(df, PATH=""):
    """
    summary => test dataset split
    :df => input dataframe
    :PATH => dataset path
    """
    df\
    .coalesce(1)\
    .write\
    .mode("overwrite")\
    .format("parquet")\
    .save(PATH)

def write_to_s3(df, PATH=""):
    """
    summary => write data partitioned by day
    :df => input dataframe
    :PATH => output data path
    """
    df\
    .sortWithinPartitions(F.col("timestamp"))\
    .write\
    .mode("overwrite")\
    .format("csv")\
    .option("header", "true")\
    .save(PATH)

def destroy_bv(bv):
    """
    summary => kill broadcast variable
    :bv => broadcast variable
    """
    return bv.destroy()

# FAD 1
print("fad1 started")
spark.conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism * 2)
fad1_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FAD_1")
fad1_union_df = union_transform_df(fad1_parquet_df)
fad1_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad1-data-items.txt")
fad1_pivots_df = pivot_transpose_df(fad1_union_df, fad1_bv)
fad1_train_df, fad1_test_df = ml_split_df(fad1_pivots_df)
write_train_to_s3(fad1_train_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet/train")
write_test_to_s3(fad1_test_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet/test")
#write_to_s3(fad1_pivots_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline//silver/silver-parquet-pivot-fad1-schema.csv")
destroy_bv(fad1_bv)
print("fad1 completed")

# FAD 2
print("fad2 started")
spark.conf.set("spark.sql.shuffle.partitions", spark.sparkContext.defaultParallelism * 2)
fad2_parquet_df = parquet_read_df(PARQUET_SOURCE_PATH, "FAD_2")
fad2_union_df = union_transform_df(fad2_parquet_df)
fad2_bv = df_to_list_to_bv("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/schemas/fad2-data-items.txt")
fad2_pivots_df = pivot_transpose_df(fad2_union_df, fad2_bv)
fad2_train_df, fad2_test_df = ml_split_df(fad2_pivots_df)
write_train_to_s3(fad2_train_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet/train")
write_test_to_s3(fad2_test_df, "s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet/test")
#write_to_s3(fad2_pivots_df, "s3://aero-iiot/datasets/e363549/pre-processing-ml-pipeline/silver/silver-parquet-pivot-fad2-schema.csv")
destroy_bv(fad2_bv)
print("fad2 completed")

# end session
spark.stop()

# garrett r peternel | spark developer | lm aeronautics