def schemaExtract(df: DataFrame): String = {
    val schema = df.schema.json
    return schema
}

import java.io._
def writeFile(path: String, json: String): Unit = {
    val file = new File(path)
    val bw = new BufferedWriter(new FileWriter(file))
    bw.write(json)
    bw.close()
}

val ac1 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac1-silver.parquet")
val ac2 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac2-silver.parquet")
val ac3 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac3-silver.parquet")
val ac4 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac4-silver.parquet")
val ac5 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-ac5-silver.parquet")

val fog1 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog1-silver.parquet")
val fog2 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fog2-silver.parquet")
val dn = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-north-silver.parquet")
val ds = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-diamond-south-silver.parquet")

val fad1 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad1-silver.parquet")
val fad2 = spark.read.parquet("s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/parquet/pivot-s3-parquet-fad2-silver.parquet")


val schema1 = schemaExtract(ac1)
val schema2 = schemaExtract(ac2)
val schema3 = schemaExtract(ac3)
val schema4 = schemaExtract(ac4)
val schema5 = schemaExtract(ac5)

val schemaf1 = schemaExtract(fog1)
val schemaf2 = schemaExtract(fog2)
val schemadn = schemaExtract(dn)
val schemads = schemaExtract(ds)

val schemafg1 = schemaExtract(fad1)
val schemafg2 = schemaExtract(fad2)


writeFile("./ac1.txt", schema1)
writeFile("./ac2.txt", schema2)
writeFile("./ac3.txt", schema3)
writeFile("./ac4.txt", schema4)
writeFile("./ac5.txt", schema5)

writeFile("./fog1.txt", schemaf1)
writeFile("./fog2.txt", schemaf2)
writeFile("./dnorth.txt", schemadn)
writeFile("./dsouth.txt", schemads)

writeFile("./fad1.txt", schemafg1)
writeFile("./fad2.txt", schemafg2)

// aws s3 cp ~ s3://aero-iiot/datasets/e363549/iiot-analytics-pipeline/silver/schemas/ --recursive

import scala.io.Source
val readFile = Source.fromFile("./ac1.txt").getLines.mkString