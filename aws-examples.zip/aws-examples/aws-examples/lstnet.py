# !/usr/bin/env python

# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

# -*- coding: utf-8 -*-

# garrett r peternel | ml specialist | lockheed martin

# desc => this model attempts to utilize the lstnet architecture via the following research paper (https://arxiv.org/abs/1703.07015) for multivariate time series iot sensor data
# source => https://github.com/apache/incubator-mxnet/issues/9326
# exec => example: python lstnet.py --data-path='/mnt/data/' --dataset='fog2.csv' --gpus=0 --model-prefix='fog2'

# deps
import os
import math
import numpy as np
import pandas as pd
import mxnet as mx
import argparse
import logging
import metrics

# args
logging.basicConfig(level=logging.DEBUG)
parser = argparse.ArgumentParser(description="LSTNet Model", formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--data-path', type=str, default='', required=True, help='input data relative path')
parser.add_argument('--dataset-name', type=str, default='', required=True, help='input data filename')
parser.add_argument('--max-rows', type=int, default=None, help='number of observations prior to data split')
parser.add_argument('--window', type=int, default=24*7, help='window size') # default when data at hourly level
parser.add_argument('--horizon', type=int, default=24, help='number of observations to predict') # default predicting 24 hours ahead
parser.add_argument('--splits', type=str, default="0.6,0.2", help='train, validation, and test set splits')
parser.add_argument('--batch-size', type=int, default=128, help='batch size')
parser.add_argument('--kernel-list', type=str, default="6,12,18", help='cnn filter sizes')
parser.add_argument('--num-filters', type=int, default=100, help='number of each filter size')
parser.add_argument('--recurrent-state-size', type=int, default=100, help='number of RNN hidden units in each unrolled recurrent cell')
parser.add_argument('--seasonal-period', type=int, default=24, help='time between seasonal measurements')
parser.add_argument('--time-interval', type=int, default=1, help='time between each measurement')
parser.add_argument('--gpus', type=str, default='', help='gpu instances (ex: 0 or 0,1,2); cpu leave empty')
parser.add_argument('--optimizer', type=str, default='adam', help='optimizer')
parser.add_argument('--lr', type=float, default=0.001, help='learning rate')
parser.add_argument('--dropout', type=float, default=0.2, help='dropout regularization')
parser.add_argument('--num-epochs', type=int, default=100, help='num of epochs')
parser.add_argument('--save-period', type=int, default=20, help='save checkpoint every n epochs')
parser.add_argument('--model-prefix', type=str, default='model', help='model params prefix name')

# func 1
def datasets(data_path, dataset, max_rows, window, horizon, splits, batch_size):
    """
    :desc: inputs ts dataset
    :return: outputs ts sequences
    """
    # read dataset
    df = pd.read_csv(os.path.join(data_dir, dataset_name), sep=",", header=None)
    features_df = df.iloc[:, 1:].astype(float) # remove 1st column (timestamp epoch)
    x = features_df.to_numpy()
    x = x[:max_rows] if max_rows else x

    # transform horizon and window ts sequences
    x_ts = np.zeros((x.shape[0] - window, window, x.shape[1]))
    y_ts = np.zeros((x.shape[0] - window, x.shape[1]))
    for i in range(x.shape[0]):
        if i + 1 < window:
            continue
        elif i + 1 + horizon > x.shape[0]:
            continue
        else:
            y_i = x[i + horizon, :]
            x_i = x[i + 1 - window:i + 1, :]
        x_ts[i-window] = x_i
        y_ts[i-window] = y_i

    # train, val, test splits
    train_set = int(x_ts.shape[0] * splits[0])
    val_set = int(x_ts.shape[0] * splits[1])
    x_train, y_train = x_ts[:train_set], y_ts[:train_set]
    x_valid, y_valid = x_ts[train_set:train_set + val_set], y_ts[train_set:train_set + val_set]
    x_test, y_test = x_ts[train_set + val_set:], y_ts[train_set + val_set:]

    # mxnet iters for network
    train_iter = mx.io.NDArrayIter(data=x_train, label=y_train, batch_size=batch_size)
    val_iter = mx.io.NDArrayIter(data=x_valid, label=y_valid, batch_size=batch_size)
    test_iter = mx.io.NDArrayIter(data=x_test, label=y_test, batch_size=batch_size)
    return train_iter, val_iter, test_iter

# func 2
def arch(train_iter, window, kernel_list, num_filters, dropout, rcells, skiprcells, seasonal_period, time_interval):
    """
    :desc: layers to architecture
    :return: dnn model architecture
    """
    # assign vars
    input_features_shape = train_iter.provide_data[0][1]
    X = mx.symbol.Variable(train_iter.provide_data[0].name)
    Y = mx.sym.Variable(train_iter.provide_label[0].name)

    # reshape data before applying cnn (can read 4d for images)
    cnn_input = mx.sym.reshape(data=X, shape=(0, 1, window, -1))

    # cnn layer
    outputs = []
    for i, filter_size in enumerate(kernel_list):
        # pad input array to ensure number output rows = number input rows after applying kernel
        padi = mx.sym.pad(data=cnn_input, mode="constant", constant_value=0, pad_width=(0, 0, 0, 0, filter_size - 1, 0, 0, 0))
        convi = mx.sym.Convolution(data=padi, kernel=(filter_size, input_features_shape[2]), num_filter=num_filters)
        acti = mx.sym.Activation(data=convi, act_type='relu')
        trans = mx.sym.reshape(mx.sym.transpose(data=acti, axes=(0, 2, 1, 3)), shape=(0, 0, 0))
        outputs.append(trans)
    cnn_features = mx.sym.Concat(*outputs, dim=2)
    cnn_regularization_features = mx.sym.Dropout(cnn_features, p=dropout)

    # rnn layer
    stacked_rnn_cells = mx.rnn.SequentialRNNCell()
    for i, recurrent_cell in enumerate(rcells):
        stacked_rnn_cells.add(recurrent_cell)
        stacked_rnn_cells.add(mx.rnn.DropoutCell(dropout))
    outputs, states = stacked_rnn_cells.unroll(length=window, inputs=cnn_regularization_features, merge_outputs=False)
    rnn_features = outputs[-1] # only return value from final unrolled cell for later use

    # skip-rnn layer
    stacked_rnn_cells = mx.rnn.SequentialRNNCell()
    for i, recurrent_cell in enumerate(skiprcells):
        stacked_rnn_cells.add(recurrent_cell)
        stacked_rnn_cells.add(mx.rnn.DropoutCell(dropout))
    outputs, states = stacked_rnn_cells.unroll(length=window, inputs=cnn_regularization_features, merge_outputs=False)

    # return output from cells p (number of hidden cells skipped through) steps apart
    p = int(seasonal_period / time_interval)
    output_indices = list(range(0, window, p))
    outputs.reverse()
    skip_outputs = [outputs[i] for i in output_indices]
    skip_rnn_features = mx.sym.concat(*skip_outputs, dim=1)

    # autoregressive layer
    ar_list = []
    for i in list(range(input_features_shape[2])):
        time_series = mx.sym.slice_axis(data=X, axis=2, begin=i, end=i+1)
        fc_ts = mx.sym.FullyConnected(data=time_series, num_hidden=1)
        ar_list.append(fc_ts)
    ar_output = mx.sym.concat(*ar_list, dim=1)

    # prediction output layer
    lstnet_components = mx.sym.concat(*[rnn_features, skip_rnn_features], dim=1)
    lstnet_output = mx.sym.FullyConnected(data=lstnet_components, num_hidden=input_features_shape[2])
    model_output = lstnet_output + ar_output
    loss_grad = mx.sym.LinearRegressionOutput(data=model_output, label=Y)
    return loss_grad, [i.name for i in train_iter.provide_data], [i.name for i in train_iter.provide_label]

def train(symbol, train_iter, val_iter, data_names, label_names):
	"""
    :desc: fit network
    :return: trained network
    """
    infra = mx.cpu() if args.gpus is None or args.gpus is '' else [mx.gpu(int(i)) for i in args.gpus.split(',')]
    module = mx.mod.Module(symbol, data_names=data_names, label_names=label_names, context=infra)
    module.bind(data_shapes=train_iter.provide_data, label_shapes=train_iter.provide_label)
    #module.init_params(mx.initializer.Uniform(0.1)) # 'Initializes weights with random values uniformly sampled from a given range'
    module.init_params(mx.initializer.Xavier(rnd_type='uniform', factor_type="in", magnitude=2.34)) # 'This initializer is designed to keep the scale of gradients roughly the same in all layers'
    module.init_optimizer(optimizer=args.optimizer, optimizer_params={'learning_rate': args.lr})

    for epoch in range(1, args.num_epochs+1):
        train_iter.reset()
        val_iter.reset()
        for batch in train_iter:
            module.forward(batch, is_train=True)  # compute preds
            module.backward()  # compute grads
            module.update() # update params

        train_pred = module.predict(train_iter).asnumpy()
        train_label = train_iter.label[0][1].asnumpy()
        print('\nMetrics: Epoch %d, Training %s' % (epoch, metrics.evaluate(train_pred, train_label)))

        val_pred = module.predict(val_iter).asnumpy()
        val_label = val_iter.label[0][1].asnumpy()
        print('Metrics: Epoch %d, Validation %s' % (epoch, metrics.evaluate(val_pred, val_label)))

        if epoch % args.save_period == 0 and epoch > 1:
            module.save_checkpoint(prefix=os.path.join("../models/", args.model_prefix), epoch=epoch, save_optimizer_states=False)
        if epoch == args.num_epochs:
            module.save_checkpoint(prefix=os.path.join("../models/", args.model_prefix), epoch=epoch, save_optimizer_states=False)

if __name__ == '__main__':
    # parse args
    args = parser.parse_args()
    args.splits = list(map(float, args.splits.split(','))) # convert to float type
    args.kernel_list = list(map(int, args.kernel_list.split(','))) # convert to int type

    # logic
    if not max(args.kernel_list) <= args.window:
        raise AssertionError("no filter can be larger than window")
    if not args.window >= math.ceil(args.seasonal_period / args.time_interval):
        raise AssertionError("size of skip connections cannot exceed window")

    # Build datasets
    train_iter, val_iter, test_iter = datasets(args.data_path, args.dataset_name, args.max_rows, args.window, args.horizon, args.splits, args.batch_size)

    # cell types for rnn layers => each cell will take the output of the previous cell in the list
    rcells = [mx.rnn.GRUCell(num_hidden=args.recurrent_state_size)]
    skiprcells = [mx.rnn.LSTMCell(num_hidden=args.recurrent_state_size)]

    # define network architecture
    symbol, data_names, label_names = arch(train_iter, args.window, args.kernel_list, args.num_filters, args.dropout, rcells, skiprcells, args.seasonal_period, args.time_interval)

    # train lstnet model
    train(symbol, train_iter, val_iter, data_names, label_names)

# garrett r peternel | ml specialist | lockheed martin