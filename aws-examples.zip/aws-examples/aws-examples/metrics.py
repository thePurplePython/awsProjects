# !/usr/bin/env python

# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

# -*- coding: utf-8 -*-

# garrett r peternel | ml specialist | lockheed martin

# deps
import numpy as np
import mxnet as mx

# metrics 1
def rse(label, pred):
    """
    :desc: computes the root relative squared error (condensed using standard deviation formula)
    :return: rse metric
    """
    numerator = np.sqrt(np.mean(np.square(label - pred), axis = None))
    denominator = np.std(label, axis = None)
    return numerator / denominator

# metrics 2
def rae(label, pred):
    """
    :desc: computes the relative absolute error (condensed using standard deviation formula)
    :return: rae metric
    """
    numerator = np.mean(np.abs(label - pred), axis=None)
    denominator = np.mean(np.abs(label - np.mean(label, axis=None)), axis=None)
    return numerator / denominator

# metrics 3
def corr(label, pred):
    """
    :desc: computes the empirical correlation coefficient
    :return: corr metric
    """
    numerator1 = label - np.mean(label, axis=0)
    numerator2 = pred - np.mean(pred, axis = 0)
    numerator = np.mean(numerator1 * numerator2, axis=0)
    denominator = np.std(label, axis=0) * np.std(pred, axis=0)
    return np.mean(numerator / denominator)


def custom_metrics():
    """
    :desc: combine metrics
    :return: mxnet metric object
    """
    _rse = mx.metric.create(rse)
    _rae = mx.metric.create(rae)
    _corr = mx.metric.create(corr)
    return mx.metric.create([_rae, _rse, _corr])

def evaluate(pred, label):
    return {"RAE":rae(label, pred), "RSE":rse(label, pred),"CORR": corr(label, pred)}

# garrett r peternel | ml specialist | lockheed martin