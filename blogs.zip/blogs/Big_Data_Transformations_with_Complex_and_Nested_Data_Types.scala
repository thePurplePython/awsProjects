
import org.apache.spark.sql.SparkSession

val spark = (SparkSession
.builder()
.appName("demos")
.master("local[8]") // use 8 cores in local mode on single machine for testing purposes only
.getOrCreate())

val jsonString = """
[
	{
		"game": "Destiny 1",
		"nest" : [
			
			{
				"release": "d1",
				"universe": {
					"class": "Titan",
					"characteristics": {
						"subclass": ["Defender"],
						"super": ["Ward of Dawn"]
					}
				}
			},

			{
				"release": "d1",
				"universe": {
					"class": "Hunter",
					"characteristics": {
						"subclass": ["Bladedancer"],
						"super": ["Arc Blade"]
					}
				}
			},

			{
				"release": "d1",
				"universe": {
					"class": "Warlock",
					"characteristics": {
						"subclass": ["Sunsigner"],
						"super": ["Radiance"]
					}
				}
			}
		]
	},

	{
		"game": "Destiny 2",
		"nest" : [
			
			{
				"release": "d2",
				"universe": {
					"class": "Titan",
					"characteristics": {
						"subclass": ["Sunbreaker", "Sentinel", "Striker"],
						"super": ["Hammer of Sol", "Sentinel Shield", "Fist of Havoc"]
					}
				}
			},

			{
				"release": "d2",
				"universe": {
					"class": "Hunter",
					"characteristics": {
						"subclass": ["Gunslinger", "Nightstalker", "Arcstrider"],
						"super": ["Golden Gun", "Shadowshot", "Arc Staff"]
					}
				}
			},

			{
				"release": "d2",
				"universe": {
					"class": "Warlock",
					"characteristics": {
						"subclass": ["Dawnblade", "Voidwalker", "Stormcaller"],
						"super": ["Daybreak", "Nova Bomb", "Stormtrance"]
					}
				}
			}
		]
	}
]
"""

import org.apache.spark.sql.types.{StructType, StringType, ArrayType}

val schema = (new StructType()
              .add("game", StringType, true)
              .add("nest", ArrayType(new StructType()
                                     .add("release", StringType, true)
                                     .add("universe", new StructType()
                                          .add("class", StringType, true)
                                          .add("characteristics", new StructType()
                                               .add("subclass", ArrayType(StringType))
                                               .add("super", ArrayType(StringType))
                                              )
                                          )
                                     )
                   )
              )


val rdd = sc.parallelize(Seq(jsonString))

val nestedDf = (spark
                .read
                .option("multiline", "true")
                .schema(schema)
                .json(rdd)
               )

nestedDf.printSchema
nestedDf.show(false)

import org.apache.spark.sql.functions.{explode}

val explodeRowsDf = nestedDf.select($"game", explode($"nest").as("row"))

val dotDf = (explodeRowsDf
             .select($"game",
                     $"row.release",
                     $"row.universe.*",
                     $"row.universe.characteristics.*")
             .drop("characteristics")
            )

import org.apache.spark.sql.functions.{arrays_zip}

val zipArraysDf = (dotDf
                   .select($"*", explode(arrays_zip($"subclass", $"super"))
                           .alias("arrayMap"))
                   .drop("subclass", "super")
                   )

val finalDf = (zipArraysDf
               .selectExpr("game",
                           "release",
                           "class",
                           "arrayMap.subclass",
                           "arrayMap.super")
               .orderBy($"class", $"game")
               )

finalDf.printSchema()
finalDf.show(false)

spark.conf.set("spark.sql.shuffle.partitions", 8) // set to something small for testing

val noAggPivotDf = (finalDf
                  .groupBy($"game")
                  .pivot($"class", Seq("Hunter", "Titan", "Warlock"))
                  .agg(expr("first(super)"))
                   )

noAggPivotDf.show()

val aggPivotDf = (finalDf
                    .groupBy($"class")
                    .pivot($"game", Seq("Destiny 1", "Destiny 2"))
                  
                    .agg(expr("count(subclass)"))
                 )

aggPivotDf.show()

noAggPivotDf.write.format("parquet").mode("overwrite").save("./table.parquet")

!ls -ltr ./table.parquet

val readDf = spark.read.parquet("./table.parquet")

readDf.printSchema()
readDf.show()
println(readDf.getClass)

%%python
read_df = spark.read.parquet("./table.parquet")

%%python
read_df.printSchema()
read_df.show()
print(type(read_df))

spark.stop()
