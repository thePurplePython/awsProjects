// garrett r peternel | spark developer | lm aeronautics

// *** prototype ***
// summary => aws step functions blog demo
// *** prototype ***

// modules
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col}


/*
spark-submit \
--class "awsStepFunctionsExampleApp" \
--master yarn \
--deploy-mode cluster \
"s3://aero-iiot/datasets/e363549/demos/aws-step-functions-example/jars/aws-step-functions-demo_2.11-1.0.jar" \
"s3://aero-iiot/datasets/e363549/demos/aws-step-functions-example/input.csv" \
"class" \ 
"s3://aero-iiot/datasets/e363549/demos/aws-step-functions-example/output.parquet"

*/

object awsStepFunctionsExampleApp {
        
        def main(args: Array[String]) {
            
            val inputPath = args(0)
            val inputColumn = args(1)
            val outputPath = args(2)
        
        /*
        val inputPath = "s3://aero-iiot/datasets/e363549/demos/aws-step-functions-example/input.csv"
        val col = "class"
        val outputPath = "s3://aero-iiot/datasets/e363549/demos/aws-step-functions-example/output.parquet"
        */
            val csvDf = readCsv(inputPath)
            writeParquet(csvDf, inputColumn, outputPath)

        }
        
        // sess
        val spark = (SparkSession
          .builder()
          .appName("aws-step-functions-example")
          .getOrCreate())

        import spark.implicits._

        // read csv
        def readCsv(inputPath: String): DataFrame = {
          val schemaDf = spark
          .read
          .format("csv")
          .option("header", "true")
          .option("inferSchema", "true")
          .load(inputPath)
          return schemaDf
        }

        // parquet write
        def writeParquet(df: DataFrame, inputColumn: String, outputPath: String) {
          return df
          .repartition(col(inputColumn))
          .write
          .partitionBy(inputColumn)
          .format("parquet")
          .mode("overwrite")
          .save(outputPath)
        }
}

// garrett r peternel | spark developer | lm aeronautics